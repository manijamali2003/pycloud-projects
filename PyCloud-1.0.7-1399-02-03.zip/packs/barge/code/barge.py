'''
from PyQt5 import QtGui,QtWidgets,QtCore
import sys

class MainApp (QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        ## Frameless the window ##
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)

        ## Customize the window  (stackoverflow.com) ##
        QtWidgets.QSizeGrip(self)

        self.resize(1000,600)
        self.setMinimumSize(100,100)
        self.setMaximumSize(1920,1080)

    ## Customize the window  (stackoverflow.com) ##
    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.__press_pos = event.pos()

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.__press_pos = None

    def mouseMoveEvent(self, event):
        if self.__press_pos:
            self.move(self.pos() + (event.pos() - self.__press_pos))

app = QtWidgets.QApplication(sys.argv)
w = MainApp()
w.show()
app.exec_()
'''

from libcloud import widget
from PyQt5 import QtWidgets

class MainWindow (QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        menubar = QtWidgets.QMenuBar()
        menubar.addMenu("&File")
        menubar.addMenu("&View")
        menubar.addMenu("&Help")
        self.setMenuBar(menubar)

class MainApp (widget.MainApp):
    def __init__(self):
        super().__init__()
        self.setMainWindow (MainWindow())
        self.setWindowTitle ("Barge")
        self.setWindowTitleColor (widget.Color.Purple,widget.Color.Pink)


app = QtWidgets.QApplication([])
w = MainApp()
w.show()
app.exec_()