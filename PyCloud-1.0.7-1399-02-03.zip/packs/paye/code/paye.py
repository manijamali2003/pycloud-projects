
import sys, libpa

from libnam import files, control, permissions, colors, process
from libcloud import core

## Check root ##
if not permissions.check_root (files.readall("/proc/info/su")):
    colors.show ("paye","perm","")
    exit(0)

## Check inputs ##
if sys.argv==[]:
    colors.show ("paye","fail","no inputs.")
    exit(0)

option = sys.argv[0]

if option=="-c":
    libpa.clean()
    colors.show("", "ok", "Clean the cache ...")

elif option=="-b":
    if files.isfile ("/app/cache/lock"):
        colors.show ("paye","fail","cache has already locked.")
        exit(0)
    else:
        files.create ("/app/cache/lock")

    if sys.argv[1:]==[]:
        colors.show("paye", "fail", "no inputs.")
        exit(0)

    dir = sys.argv[1:]

    for i in dir:
        libpa.build(i)
        colors.show("", "ok", "Build the '" + i + "' project ...")

    libpa.clean()


elif option=="-u":
    if files.isfile ("/app/cache/lock"):
        colors.show ("paye","fail","cache has already locked.")
        exit(0)
    else:
        files.create ("/app/cache/lock")

    if sys.argv[1:]==[]:
        colors.show("paye", "fail", "no inputs.")
        exit(0)

    archive = sys.argv[1:]

    want = input ("Do you want to install these packages? [Y/n]: ")
    if want.upper()=="Y":
        for i in archive:
            if files.isfile(i):
                libpa.unpack(i)
                colors.show("", "ok", "Unpack '" + i + "' archive package ...")

            else:
                colors.show("paye", "fail", i + ": archive not found.")
    else:
        print ("Abort.")

    libpa.clean()

elif option=="-r":
    if files.isfile ("/app/cache/lock"):
        colors.show ("paye","fail","cache has already locked.")
        exit(0)
    else:
        files.create ("/app/cache/lock")

    if sys.argv[1]==[]:
        colors.show("paye", "fail", "no inputs.")
        exit(0)

    package = sys.argv[1:]

    want = input("Do you want to remove these packages? [Y/n]: ")

    if want.upper() == "Y":
        for i in package:
            libpa.remove(i.lower())
            colors.show("", "ok", "Remove '" + i.lower() + "' package ...")
    else:
        print ("Abort.")

    libpa.clean()

elif option=="-d":

    if sys.argv[1]==[]:
        colors.show("paye", "fail", "no inputs.")
        exit(0)

    package = sys.argv[1:]

    for i in package:
        colors.show (i.lower(),"get","")
        libpa.download (i.lower())

elif option=="-i":
    if files.isfile ("/app/cache/lock"):
        colors.show ("paye","fail","cache has already locked.")
        exit(0)
    else:
        files.create ("/app/cache/lock")

    if sys.argv[1]==[]:
        colors.show("paye", "fail", "no inputs.")
        exit(0)

    package = sys.argv[1:]

    want = input("Do you want to install these packages? [Y/n]: ")
    if want.upper() == "Y":
        for i in package:
            colors.show(i.lower(), "get", "")
            libpa.download(i.lower())

        for j in package:
            libpa.unpack("/app/cache/gets/" + j.lower() + ".pa")
            colors.show("", "ok", "Unpack '.../" + j.lower() + ".pa' archive package ...")
    else:
        print ("Abort.")

    libpa.clean()
else:
    colors.show ("paye","fail",option+": option not found.")