
import sys, os

os.system ("\""+sys.executable+"\" build.py")
os.system ("\""+sys.executable+"\" configure.py")
os.system ("\""+sys.executable+"\" build-config.py")
