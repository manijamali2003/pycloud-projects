from libnam import files, control, colors, permissions
from libcloud import core
import shutil, requests

## Clean the cache ##
def clean():
    if permissions.check_root(files.readall ("/proc/info/su")):
        if files.isdir ("/app/cache"):
            files.removedirs ("/app/cache")
            files.mkdir("/app/cache")
            files.mkdir("/app/cache/gets")
            files.mkdir("/app/cache/archives")
            files.mkdir("/app/cache/archives/code")
            files.mkdir("/app/cache/archives/control")
            files.mkdir("/app/cache/archives/data")
            files.mkdir("/app/cache/archives/build")
    else:
        colors.show ("libpa.clean","perm","")

## Create .pa archive ##

def build(name):
    if permissions.check_root(files.readall ("/proc/info/su")):
        if not (files.isdir (name+"/code") and files.isdir(name+"/data") and files.isdir(name+"/control") and files.isfile (name+"/control/manifest")):
            colors.show ("libpa.build","fail","cannot create archive package")
            clean()
            exit(0)

        shutil.make_archive(files.input("/app/cache/archives/build/data"),"xztar",files.input(name+"/data"))
        shutil.make_archive(files.input("/app/cache/archives/build/code"), "xztar", files.input(name+"/code"))
        shutil.make_archive(files.input("/app/cache/archives/build/control"), "xztar", files.input(name+"/control"))

        shutil.make_archive(files.input(name),"zip",files.input("/app/cache/archives/build"))
        files.cut (name+".zip",name+".pa")
        ## Unlock the cache ##
    else:
        colors.show ("libpa.build","perm","")

## Unpack .pa archives ##

def unpack (name):
    if permissions.check_root(files.readall("/proc/info/su")):
        ## unpack package ##
        shutil.unpack_archive(files.input(name),files.input("/app/cache/archives/build"),"zip")

        shutil.unpack_archive(files.input("/app/cache/archives/build/data.tar.xz"),files.input("/app/cache/archives/data"),"xztar")
        shutil.unpack_archive(files.input("/app/cache/archives/build/code.tar.xz"), files.input("/app/cache/archives/code"), "xztar")
        shutil.unpack_archive(files.input("/app/cache/archives/build/control.tar.xz"), files.input("/app/cache/archives/control"), "xztar")

        ## Get database of this package ##
        name = control.read_record("name", "/app/cache/archives/control/manifest").lower()
        unpack = control.read_record("unpack", "/app/cache/archives/control/manifest")
        depends = control.read_record("depends","/app/cache/archives/control/manifest")

        if not (depends==None):
            depends.split(",")

        ## Search for tree dependency ##

        if not depends==None:
            for i in depends:
                if not files.isfile("/app/packages/" + i + ".manifest"):
                    colors.show("libpa.unpack", "fail", name + " depends " + i + " package.")
                    clean()
                    exit(0)

        ## Write dependency ##

        if not depends == None:
            for i in depends:
                files.create("/app/packages/" + i + ".depends")
                files.write("/app/packages/" + i + ".depends", name + "\n")

        ## Run preinstall script ##

        if files.isfile ("/app/cache/archives/control/preinstall.py"):
            files.compile("/app/cache/archives/control/preinstall.py","/app/cache/archives/control/preinstall.pyc")
            files.remove("/app/cache/archives/control/preinstall.py")

            if files.isfile ("/app/cache/archives/control/postinstall.py"):

                files.compile("/app/cache/archives/control/postinstall.py", "/app/cache/archives/control/postinstall.pyc")
                files.remove ("/app/cache/archives/control/postinstall.py")

            if files.isfile("/app/cache/archives/control/preremove.py"):
                files.compile("/app/cache/archives/control/preremove.py",
                              "/app/cache/archives/control/preremove.pyc")
                files.remove("/app/cache/archives/control/preremove.py")

            if files.isfile("/app/cache/archives/control/postremove.py"):
                files.compile("/app/cache/archives/control/postremove.py",
                              "/app/cache/archives/control/postremove.pyc")
                files.remove("/app/cache/archives/control/postremove.py")

            core.system ("/app/cache/archives/control/preinstall")

        elif files.isfile ("/app/cache/archives/control/preinstall.pyc"):
            core.system("/app/cache/archives/control/preinstall")

        ## Setting up ##

        if files.isfile ("/app/cache/archives/control/list"): files.copy("/app/cache/archives/control/list","/app/packages/"+name+".list")
        if files.isfile ("/app/cache/archives/control/manifest"): files.copy("/app/cache/archives/control/manifest","/app/packages/"+name + ".manifest")
        if files.isfile ("/app/cache/archives/control/postinstall.pyc"): files.copy("/app/cache/archives/control/postinstall.pyc","/app/packages/"+ name + ".postinstall")
        if files.isfile ("/app/cache/archives/control/postremove.pyc"): files.copy("/app/cache/archives/control/postremove.pyc","/app/packages/"+ name + ".postremove")
        if files.isfile ("/app/cache/archives/control/preinstall.pyc"): files.copy("/app/cache/archives/control/preinstall.pyc","/app/packages/"+ name + ".preinstall")
        if files.isfile ("/app/cache/archives/control/preremove.pyc"): files.copy("/app/cache/archives/control/preremove.pyc","/app/packages/"+ name + ".preremove")
        if files.isfile ("/app/cache/archives/control/compile"): files.copy("/app/cache/archives/control/compile","/app/packages/"+ name + ".compile")

        ## Compile codes ##
        if files.isfile ("/app/cache/archives/control/compile"):
            listcodes = control.read_list("/app/cache/archives/control/compile")
            for i in listcodes:
                i = i.split(":")
                files.compile("/app/cache/archives/code/" + i[0], "/app/cache/archives/data/" + i[1])

        ## Save source codes ##

        if files.isfile ("/app/cache/archives/control/compile"):
            shutil.unpack_archive(files.input("/app/cache/archives/build/code.tar.xz"),files.input("/usr/src/"+name),"xztar")

        ## Archive data again ##
        shutil.make_archive(files.input("/app/cache/archives/build/data"),"xztar",files.input("/app/cache/archives/data"))

        ## Unpack data again ##
        shutil.unpack_archive(files.input("/app/cache/archives/build/data.tar.xz"),files.input(unpack),"xztar")

        ## After install ##

        ## Run post install script ##

        if files.isfile("/app/cache/archives/control/postinstall.pyc"):
            core.system("/app/cache/archives/control/postinstall")

        ## Unlock the cache ##
    else:
        colors.show("libpa.unpack", "perm", "")

def remove (name):
    if permissions.check_root(files.readall("/proc/info/su")):

        location = "/app/packages/" + name.lower() + ".manifest"

        if not files.isfile(location):
            colors.show("libpa.remove", "fail", name + ": package not found")
            clean()
            exit(0)

        ## Database control ##

        list = "/app/packages/" + name.lower() + ".list"
        preinstall = "/app/packages/"+name.lower()+".preinstall"
        postinstall = "/app/packages/"+name.lower()+".postinstall"
        preremove = "/app/packages/"+name.lower()+".preremove"
        postremove = "/app/packages/"+name.lower()+".postremove"
        compile = "/app/packages/"+name.lower()+".compile"
        depends = "/app/packages/"+name.lower()+".depends"


        ## Create preremove and postremove copies ##

        if files.isfile(preremove): files.copy(preremove,"/app/cache/archives/control/preremove.pyc")
        if files.isfile(postremove): files.copy(postremove, "/app/cache/archives/control/postremove.pyc")

        ## Run pre remove script ##

        if files.isfile("/app/cache/archives/control/preremove.pyc"):
            core.system("/app/cache/archives/control/preremove")

        ## Remove depends ##

        if files.isfile(depends):
            depends = control.read_list(depends)
            for i in depends:
                remove(i)

        ####################

        unpack = control.read_record("unpack",location)

        ## Unpacked removal ##
        filelist = control.read_list(list)

        for i in filelist:
            if files.isdir (unpack+"/"+i):
                files.removedirs(unpack + "/" + i)
            elif files.isfile (unpack+"/"+i):
                files.remove (unpack+"/"+i)

        ## Database removal ##

        if files.isfile (location): files.remove (location)
        if files.isfile(compile): files.remove(compile)
        if files.isfile(list): files.remove(list)
        if files.isfile(preinstall): files.remove(preinstall)
        if files.isfile(postinstall): files.remove(postinstall)
        if files.isfile(preremove): files.remove(preremove)
        if files.isfile(postremove): files.remove(postremove)
        if files.isfile (depends): files.remove(depends)

        ## Run postremove script ##

        if files.isfile("/app/cache/archives/control/postremove.pyc"):
            core.system("/app/cache/archives/control/postremove")

    else:
        colors.show ("libpa.remove","perm","")

def download (packname):
    if permissions.check_root(files.readall("/proc/info/su")):
        repo = control.read_record("repo","/etc/repo")
        stable = control.read_record("stable","/etc/repo")

        import requests
        r = requests.get(repo + "/" + packname)
        with open(files.input("/app/cache/gets/" + packname), "wb") as code:
            code.write(r.content)

        name = control.read_record("name", "/app/cache/gets/" + packname)

        if stable=="Yes":
            main = control.read_record("stable", "/app/cache/gets/" + packname)
            main = main.split(",")
            version = main[0]
            build = main[1]
        else:
            main = control.read_record("unstable","/app/cache/gets/"+packname)
            main = main.split(",")
            version = main[0]
            build = main[1]

        if name == None or build == None or version == None:
            colors.show("libpa.download", "fail", packname + ": package not found.")
            exit(0)

        r = requests.get(repo + "/" + name + "-" + version + "-" + build + ".pa")
        with open(files.input("/app/cache/gets/" + name+".pa"), "wb") as code:
            code.write(r.content)

    else:
        colors.show ("libpa.download","perm","")