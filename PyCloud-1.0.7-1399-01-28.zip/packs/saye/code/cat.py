import sys, os, hashlib
from libnam import files, control, permissions, colors, process


def cat (option,name,eof):
    if option=="":
        if files.isfile (name):
            if permissions.check(files.output(name), "r", files.readall("/proc/info/su")):
                file = open(files.input(name), "rb")
                check_bin = str(file.read())
                file.close()
                if check_bin.__contains__("\\x00"):
                    print(check_bin)
                else:
                    print(files.readall(name))
            else:
                colors.show ("cat","perm","")
        elif files.isdir (name):
            colors.show("cat", "fail", name + ": is a directory.")
        else:
            colors.show("cat", "fail", name + ": file not found.")
    elif option=="-c":
        if files.isdir (name):
            colors.show("cat", "fail", name + ": is a directory.")
        else:
            if permissions.check(files.output(name), "w", files.readall("/proc/info/su")):
                files.create(name)
            else:
                colors.show ("cat","perm","")
    elif option=="-w":
        if files.isdir (name):
            colors.show("cat", "fail", name + ": is a directory.")
        else:
            if permissions.check(files.output(name), "w", files.readall("/proc/info/su")):
                text = ""
                while True:
                    line = input("> ")
                    if line == eof:
                        files.write(name, text)
                        break
                    if text == "":
                        text = text + line
                    else:
                        text = text + "\n" + line
            else:
                colors.show ("cat","perm","")
    elif option=="-a":
        if files.isdir (name):
            colors.show("cat", "fail", name + ": is a directory.")
        else:
            if permissions.check(files.output(name), "w", files.readall("/proc/info/su")):
                text = ""
                while True:
                    line = input("> ")
                    if line == eof:
                        files.append(name, text)
                        break
                    if text == "":
                        text = text + line
                    else:
                        text = text + "\n" + line
            else:
                colors.show ("cat","perm","")

cmdln = ['']
cmdln[1:] = sys.argv

if not cmdln[1:] == []:
    if cmdln[2:] == []:
        cat("", cmdln[1], "")
    else:
        if cmdln[1] == "-c":
            cat("-c", cmdln[2], "")
        elif cmdln[1] == "-w":
            if cmdln[3:] == []:
                cat("-w", cmdln[2], "EOF")
            else:
                cat("-w", cmdln[2], cmdln[3])
        elif cmdln[1] == "-a":
            if cmdln[3:] == []:
                cat("-a", cmdln[2], "EOF")
            else:
                cat("-a", cmdln[2], cmdln[3])
else:
    colors.show("cat", "fail", "no inputs.")