# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'barge.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_DockWidget(object):
    def setupUi(self, DockWidget):
        DockWidget.setObjectName("DockWidget")
        DockWidget.resize(1000, 600)
        DockWidget.setMouseTracking(False)
        DockWidget.setFeatures(QtWidgets.QDockWidget.AllDockWidgetFeatures)

        self.retranslateUi(DockWidget)
        QtCore.QMetaObject.connectSlotsByName(DockWidget)

    def retranslateUi(self, DockWidget):
        _translate = QtCore.QCoreApplication.translate
        DockWidget.setWindowTitle(_translate("DockWidget", "Barge"))

DockWidget = QtWidgets.QDockWidget()
ui = Ui_DockWidget()
ui.setupUi(DockWidget)
w = DockWidget