from buildlibs import pack_archives as pack
import shutil, os

shutil.rmtree("stor")
os.mkdir ("stor")
os.mkdir ("stor/app")
os.mkdir ("stor/app/packages")

pack.build ("namnam")
pack.build ("paye")
pack.build ("saye")

pack.unpack ("namnam")
pack.unpack ("paye")
pack.unpack ("saye")