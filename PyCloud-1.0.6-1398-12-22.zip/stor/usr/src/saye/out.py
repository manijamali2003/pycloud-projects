import sys

for i in sys.argv:
    print(
        i
            .replace("-a", "\a")
            .replace("-b", "\b")
            .replace("-f", "\f")
            .replace("-n", "\n")
            .replace("-r", "\r")
            .replace("-t", "\t")
            .replace("-v", "\v")
        , end=' ')