import sys, os, hashlib
from libnam import files, control, permissions, colors, process
from libcloud import core

if sys.argv==[]:
    colors.show ("saye","fail","no inputs.")
    exit(0)

filename = sys.argv[0]

if not permissions.check (files.output(filename),"x",files.readall("/proc/info/su")):
    colors.show ("saye","perm","")
    exit(0)

cmdall = control.read_list (filename)

k = 0

for cmd in cmdall:
    k = k + 1
    ## Create cmdln with variables ##
    cmdln = cmd.split (" ")

    strcmdln = ""

    for i in cmdln:
        if str(i).startswith("$"):
            select = files.readall("/proc/info/sel")
            var = control.read_record(str(i).replace("$", ""), select)
            if var == None:
                strcmdln = strcmdln + " " + i
            else:
                strcmdln = strcmdln + " " + var
        else:
            strcmdln = strcmdln + " " + i

    cmdln = strcmdln.split(" ")
    cmdln.remove('')

    cmd = ""
    for j in cmdln:
        cmd = cmd + " " + j

    if (cmdln == [] or
            cmdln[0] == "" or
            cmdln[0] == " " or
            cmd.startswith("#") or
            cmd.startswith("//") or
            (cmd.startswith("/*") and cmd.endswith("*/")) or
            (cmd.startswith("\'\'\'") and cmd.endswith("\'\'\'")) or
            cmd.startswith(";")
    ):
        continue
    else:
        core.system (cmd)