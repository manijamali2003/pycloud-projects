import sys, os, hashlib
from libnam import files, control, permissions, colors, process

def set (name,value):
    select = files.readall("/proc/info/sel")
    if not select.startswith ("/proc/"):
        if permissions.check(files.output(select),"w",files.readall("/proc/info/su")):
            control.write_record(name, value, select)
        else:
            colors.show ("set","perm","")
    else:
        control.write_record(name,value,select)


if sys.argv == []:
    colors.show("set", "fail", "no inputs.")
else:
    if sys.argv[1:] == []:
        colors.show("set", "fail", "no inputs.")
    else:
        if sys.argv[0].endswith(":"):
            set(sys.argv[0].replace(":", ""), sys.argv[1])
        else:
            colors.show("set", "fail", "wrong syntax.")