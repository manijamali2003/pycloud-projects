
import sys, libpa

from libnam import files, control, permissions, colors, process

## Check root ##
if not permissions.check_root (files.readall("/proc/info/su")):
    colors.show ("paye","perm","")
    exit(0)

## Check inputs ##
if sys.argv==[]:
    colors.show ("paye","fail","no inputs.")
    exit(0)

option = sys.argv[0]

if option=="-c":
    libpa.clean()
    colors.show("", "ok", "Clean the cache ...")

elif option=="-b":

    if sys.argv[1:]==[]:
        colors.show("paye", "fail", "no inputs.")
        exit(0)

    dir = sys.argv[1]

    libpa.build (dir)
    colors.show("", "ok", "Build the '" + dir + "' project ...")

elif option=="-u":

    if sys.argv[1:]==[]:
        colors.show("paye", "fail", "no inputs.")
        exit(0)

    archive = sys.argv[1]

    if files.isfile (archive):
        libpa.unpack (archive)
        colors.show("", "ok", "Unpack '" + archive + "' archive package ...")
    else:
        colors.show ("paye","fail",archive+": archive not found.")

elif option=="-r":

    if sys.argv[1]==[]:
        colors.show("paye", "fail", "no inputs.")
        exit(0)

    package = sys.argv[1]

    libpa.remove (package)

else:
    colors.show ("paye","fail",option+": option not found.")