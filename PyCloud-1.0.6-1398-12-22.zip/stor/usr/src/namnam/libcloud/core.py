
from libnam import process, files, permissions, colors, control
import os, importlib

## Shutdown a switched process ## [#]
def end (switch):
    su = files.readall ("/proc/info/su")
    if permissions.check_root(su):
        process.end (switch)
    else:
        colors.show ("libcloud.core.end","perm","")

## Shutdown the clouding system ## [#]
def shutdown ():
    su = files.readall("/proc/info/su")
    if permissions.check_root(su):
        if files.isfile("/proc/selected"): files.remove("/proc/selected")
        if files.isdir("/desk/guest"):     files.removedirs("/desk/guest")
        process.endall()
    else:
        colors.show ("libcloud.core.shutdown","perm","")

## Restart the clouding system ## [#]
def reboot ():
    su = files.readall("/proc/info/su")
    py = files.readall("/proc/info/py")
    if permissions.check_root(su):
        if files.isfile("/proc/selected"): files.remove("/proc/selected")
        if files.isdir("/desk/guest"):     files.removedirs("/desk/guest")
        process.endall()
        os.system(py + " vmnam.pyc")
    else:
        colors.show("libcloud.core.shutdown", "perm", "")

## Select a database ## [#]
def select (name):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(name), "r", su):
        if files.isfile(name):
            files.write("/proc/info/sel", name)
            files.create("/proc/selected")
        else:
            colors.show("libcloud.core.select", "fail", name + ": database not found.")
    else:
        colors.show("libcloud.core.select", "perm", "")

## Set a variable ## [#]
def set (name,value):
    su = files.readall("/proc/info/su")
    sel = files.readall("/proc/info/sel")
    if permissions.check(files.output(name), "w", su):
        control.write_record(name, value, sel)
    else:
        colors.show("libcloud.core.set", "perm", "")

## Set a variable ## [#]
def unset (name):
    su = files.readall("/proc/info/su")
    sel = files.readall("/proc/info/sel")
    if permissions.check(files.output(name), "w", su):
        control.remove_record(name, sel)
    else:
        colors.show("libcloud.core.unset", "perm", "")

## Unselect the database ## [#]
def unselect ():
    sp = files.readall("/proc/info/sp")
    sel = files.readall("/proc/info/sel")
    if sel == "/proc/" + sp:
        colors.show("libcloud.core.unselect", "warning", "database has already selected.")
    else:
        files.write("/proc/info/sel", "/proc/" + sp)
        if files.isfile("/proc/selected"): files.remove("/proc/selected")

## Execute an application ## [#]
def execute (name):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(name+".pyc"),"x",su):
        if files.isfile (name+".pyc"):
            importlib.import_module(files.input_exec(name))
        else:
            colors.show ("libcloud.core.execute","fail",name+": program not found.")
    elif permissions.check(files.output(name + ".py"), "x", su):
        if files.isfile(name + ".py"):
            importlib.import_module(files.input_exec(name))
        else:
            colors.show("libcloud.core.execute", "fail", name + ": program not found.")
    else:
        colors.show ("libcloud.core.execute","perm","")

## Import a module ## [#]
def using (name):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(name+".pyc"),"r",su) and permissions.check(files.output(name+".pyc"),"x",su):
        if files.isfile (name+".pyc"):
            return importlib.import_module(files.input_exec(name))
        else:
            colors.show ("libcloud.core.using","fail",name+": module not found.")

    elif permissions.check(files.output(name+".py"),"r",su) and permissions.check(files.output(name+".py"),"x",su):
        if files.isfile (name+".py"):
            return importlib.import_module(files.input_exec(name))
        else:
            colors.show ("libcloud.core.using","fail",name+": module not found.")
    else:
        colors.show ("libcloud.core.using","perm","")

## Chmod ## [#]

def chmod (mod,name):
    su = files.readall("/proc/info/su")
    perm_user = int(mod[0])
    perm_others = int(mod[1])
    perm_guest = int(mod[2])
    if permissions.check_owner(files.output(name), su):
        owner = permissions.get_owner(files.output(name))
        permissions.create(files.output(name), perm_user, perm_others, perm_guest, owner)
    else:
        colors.show("libcloud.core.chmod", "perm", "")

## System ##

def system (cmd):
    os.system (files.readall ("/proc/info/py")+" vmnam.pyc exec "+cmd)