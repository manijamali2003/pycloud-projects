
from libnam import files, control, colors, permissions
import shutil

def zip (src,dest):
    su = files.readall("/proc/info/su")
    if permissions.check (files.output(src),"r",su):
        if permissions.check (files.output(dest+".zip"),"r",su):
            if files.isdir (src):
                if files.isdir (dest+".zip"):
                    colors.show("libcloud.archive.zip", "fail", dest+".zip" + ": dest is a directory.")
                else:
                    shutil.make_archive(files.input(dest),"zip",files.input(src))
            elif files.isfile (src):
                colors.show("libcloud.archive.zip", "fail",src+ ": source is a file.")
            else:
                colors.show("libcloud.archive.zip", "fail",src+ ": source not found.")
        else:
            colors.show("libcloud.archive.zip", "perm", "")
    else:
        colors.show ("libcloud.archive.zip","perm","")

def tarball (src,dest):
    su = files.readall("/proc/info/su")
    if permissions.check (files.output(src),"r",su):
        if permissions.check (files.output(dest+".tar"),"r",su):
            if files.isdir (src):
                if files.isdir (dest+".tar"):
                    colors.show("libcloud.archive.tarball", "fail", dest+".tar" + ": dest is a directory.")
                else:
                    shutil.make_archive(files.input(dest),"tar",files.input(src))
            elif files.isfile (src):
                colors.show("libcloud.archive.tarball", "fail",src+ ": source is a file.")
            else:
                colors.show("libcloud.archive.tarball", "fail",src+ ": source not found.")
        else:
            colors.show("libcloud.archive.tarball", "perm", "")
    else:
        colors.show ("libcloud.archive.tarball","perm","")