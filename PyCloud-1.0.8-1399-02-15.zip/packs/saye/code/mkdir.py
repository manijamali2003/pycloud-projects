
import sys, os, hashlib
from libnam import files, control, permissions, colors, process

def mkdir (names):
    for i in names:
        if files.isfile (i):
            colors.show("mkdir", "fail", i + ": is a file.")
        elif files.isdir (i):
            colors.show("mkdir", "warning", i + ": directory exists.")
        else:
            if permissions.check (files.output(i),"w",files.readall("/proc/info/su")):
                files.makedirs (i)
            else:
                colors.show ("mkdir","perm","")
mkdir(sys.argv)