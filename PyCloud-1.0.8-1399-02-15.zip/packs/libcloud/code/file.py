from libnam import files, permissions, colors, control

def create (name):
    su = files.readall("/proc/info/su")
    if permissions.check (files.output(name),"w",su):
        if isdir (name):
            colors.show("libcloud.file.create", "fail", name + ": is a directory.")
        else:
            files.create (name)
    else:
        colors.show("libcloud.file.create", "perm", "")

def write (name,text):
    su = files.readall("/proc/info/su")
    if permissions.check (files.output(name),"w",su):
        if isdir (name):
            colors.show("libcloud.file.write", "fail", name + ": is a directory.")
        else:
            files.write (name,text)
    else:
        colors.show("libcloud.file.write", "perm", "")

def readall (name):
    su = files.readall("/proc/info/su")
    if permissions.check (files.output(name),"r",su):
        if files.isfile (name):
            file = open(files.input(name), "rb")
            check_bin = str(file.read())
            file.close()
            if check_bin.__contains__("\\x00"):
                return check_bin
            else:
                return files.readall(name)
        else:
            colors.show("libcloud.file.readall", "fail", name + ": file not found.")
    else:
        colors.show("libcloud.file.readall", "perm", "")
def append (name,text):
    su = files.readall("/proc/info/su")
    if permissions.check (files.output(name),"w",su):
        if isdir (name):
            colors.show("libcloud.file.append", "fail", name + ": is a directory.")
        else:
            files.append (name,text)
    else:
        colors.show("libcloud.file.append", "perm", "")

def isfile (name):
    su = files.readall("/proc/info/su")
    if permissions.check (files.output(name),"r",su):
        return files.isfile (name)
    else:
        colors.show("libcloud.file.isfile", "perm", "")
        return None

def isdir (name):
    su = files.readall("/proc/info/su")
    if permissions.check (files.output(name),"r",su):
        return files.isdir (name)
    else:
        colors.show("libcloud.file.isdir", "perm", "")
        return None

def mkdir (name):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(name), "w", su):
        if isfile (name):
            colors.show("libcloud.file.mkdir", "fail", name + ": is a file.")
        else:
            files.makedirs(name)
    else:
        colors.show("libcloud.file.mkdir", "perm", "")

def remove (name):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(name), "w", su):
        if isfile (name):
            files.remove (name)
        elif isdir (name):
            files.removedirs (name)
        else:
            colors.show ("libcloud.file.remove","fail",name+": file or directory not found.")
    else:
        colors.show("libcloud.file.remove", "perm", "")

def copy (src,dest):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(src), "r", su):
        if isfile (src):
            if permissions.check(files.output(dest), "w", su):
                if files.isdir (dest):
                    colors.show("libcloud.file.copy", "fail", dest + ": dest is a directory.")
                else:
                    perm = permissions.get_permissions(files.output(src))
                    control.write_record(files.output(dest), perm, "/etc/permtab")
                    files.copy (src,dest)
            else:
                colors.show("libcloud.file.copy", "perm", "")
        elif isdir (src):
            if permissions.check(files.output(dest), "w", su):
                if files.isfile(dest):
                    colors.show("libcloud.file.copy", "fail", dest + ": dest is a file.")
                else:
                    perm = permissions.get_permissions(files.output(src))
                    control.write_record(files.output(dest), perm, "/etc/permtab")
                    files.copydir(src, dest)
            else:
                colors.show("libcloud.file.copy", "perm", "")
        else:
            colors.show ("libcloud.file.copy","fail",src+": source not found.")
    else:
        colors.show("libcloud.file.copy", "perm", "")

def cut (src,dest):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(src), "r", su) and  permissions.check(files.output(src), "w", su):
        if isfile (src):
            if permissions.check(files.output(dest), "w", su):
                if files.isdir (dest):
                    colors.show("libcloud.file.cut", "fail", dest + ": dest is a directory.")
                else:
                    perm = permissions.get_permissions(files.output(src))
                    control.write_record(files.output(dest), perm, "/etc/permtab")
                    files.cut (src,dest)
            else:
                colors.show("libcloud.file.cut", "perm", "")
        elif isdir (src):
            if permissions.check(files.output(dest), "w", su):
                if files.isfile(dest):
                    colors.show("libcloud.file.cut", "fail", dest + ": dest is a file.")
                else:
                    perm = permissions.get_permissions(files.output(src))
                    control.write_record(files.output(dest), perm, "/etc/permtab")
                    files.cutdir(src, dest)
            else:
                colors.show("libcloud.file.cut", "perm", "")
        else:
            colors.show ("libcloud.file.cut","fail",src+": source not found.")
    else:
        colors.show("libcloud.file.cut", "perm", "")

def list (name):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(name), "r", su):
        return files.list (name)
    else:
        colors.show("libcloud.file.list", "perm", "")
        return []

def compile (src,dest):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(src), "r", su):
        if isfile (src):
            if permissions.check(files.output(dest), "w", su):
                if files.isdir (dest):
                    colors.show("libcloud.file.compile", "fail", dest + ": dest is a directory.")
                else:
                    files.compile (src,dest)
            else:
                colors.show("libcloud.file.compile", "perm", "")
        elif isdir (src):
            colors.show("libcloud.file.compile", "fail", src + ": source is a directory.")
        else:
            colors.show ("libcloud.file.compile","fail",src+": source not found.")
    else:
        colors.show("libcloud.file.compile", "perm", "")

def res (filename):
    model = control.read_record ("model","/etc/gui") # read model
    filename = filename.split (":") # @widget:barge.ui

    share = filename[0]
    name = filename[1]

    # widgets file #
    if share.startswith ("@"):
        return files.input("/usr/share/"+share.replace("@","")+"/"+model+"/"+name)
    else:
        return None