from libnam import process, files, permissions, colors, control, modules
import os, importlib, getpass, sys

## Graphical application library ##

## Run app ##
def system (cmd):
    os.system (files.readall ("/proc/info/py")+" vmnam.pyc exec app "+cmd)

'''
## Input Dialogs ##
def inputdialog (output):
    files.write("/tmp/input-title", output)
    system("inputdialog")
    files.remove("/tmp/input-title")

    if files.isfile("/tmp/input"):
        strv = files.readall("/tmp/input")
        files.remove("/tmp/input")
        return strv
    else:
        return ""

def codedialog (output):
    files.write("/tmp/input-title", output)
    system("codedialog")
    files.remove("/tmp/input-title")

    if files.isfile("/tmp/input"):
        strv = files.readall("/tmp/input")
        files.remove("/tmp/input")
        return strv
    else:
        return ""

## Message Box ##

def messagebox (message):
    files.write("/tmp/messagebox",message)
    system("messagebox")
    files.remove ("/tmp/messagebox")'''