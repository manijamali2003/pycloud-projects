from PyQt5 import QtWidgets, uic, QtCore, QtGui
import sys
from libcloud import core, app
from libnam import files, permissions

class MainApp(QtWidgets.QMainWindow):
    def btnOK_act (self):
        input = self.leInput.text() # Get input text
        files.write ("/tmp/input",input) # Write input file
        exit()

    def __init__(self):
        super(MainApp, self).__init__()
        uic.loadUi(files.input("/usr/share/widgets/inputdialog.ui"),self)

        ## Get input title ##
        if files.isfile ("/tmp/input-title"):
            self.setWindowTitle(files.readall ("/tmp/input-title"))

        ## finds ##
        self.leInput = self.findChild(QtWidgets.QLineEdit,'leInput')
        self.leInput.setEchoMode (QtWidgets.QLineEdit.Password)
        self.btnCancel = self.findChild(QtWidgets.QPushButton, 'btnCancel')
        self.btnOK = self.findChild(QtWidgets.QPushButton, 'btnOK')

        ## Clicks ##
        self.btnCancel.clicked.connect (exit)
        self.btnOK.clicked.connect (self.btnOK_act)
        self.show()