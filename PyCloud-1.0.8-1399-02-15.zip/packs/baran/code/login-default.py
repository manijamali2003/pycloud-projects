from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import uic
from libnam import files, control, process
import importlib, hashlib
from importlib import reload
from libcloud import core

from PyQt5 import QtCore, QtGui, QtWidgets

class MainApp (QMainWindow):
    fontsize = control.read_record("fontsize", "/etc/gui") # Get font size
    model = control.read_record("model", "/etc/gui") # Get screen model
    locale = control.read_record("locale","/etc/gui") # Get locale
    def suspend_act(self):
        import suspendpage
        w1 = suspendpage.w
        importlib.reload(suspendpage) ##https://www.geeksforgeeks.org/reloading-modules-python/
    def escape_act(self):
        core.shutdown()
        exit(0)
    def restart_act(self):
        core.reboot()
        exit(0)

    def enter(self):
        self.close()
        import enter
        w1 = enter.w

    def desktop(self):
        self.close()
        import desktop
        w1 = desktop.w

    def check_user(self):
        self.username = self.leUsername.text().lower()
        self.enable_gui = control.read_record("enable_gui", "/etc/guest")

        ## If user is guest
        if self.username == "guest" and self.enable_gui == "Yes":
            self.leUsername.setEnabled(False)
            files.write("/tmp/username.tmp", self.username)
            files.create("/tmp/su.tmp")
            control.write_record("username", self.username, "/tmp/su.tmp")
            control.write_record("code", "", "/tmp/su.tmp")
            QTimer.singleShot(0,self.desktop)

        ## If user is x
        elif files.isfile("/etc/users/" + self.username):
            self.hashname = hashlib.sha3_256(
                str(self.username).encode()).hexdigest()

            self.user = control.read_record("username", "/etc/users/" + self.username)

            if self.user == self.hashname:
                files.write("/tmp/username.tmp", self.username)
                QTimer.singleShot(1000,self.enter)
            else:
                self.lblUserNotFound.setText(self.lc_lblUserNotFound.replace("{0}", self.username))
                QTimer.singleShot(1000, self.clear)
        else:
            self.lblUserNotFound.setText(self.lc_lblUserNotFound.replace("{0}", self.username))
            QTimer.singleShot(1000, self.clear)

    ## Clear wrongs
    def clear(self):
        self.lblUserNotFound.clear()
        self.leUsername.clear()

    def __init__(self):
        super().__init__()

        ## Load ui ##
        uic.loadUi(files.input ('/usr/share/widgets/'+self.model+'/default.ui'),self)

        ## Frameless the window ##
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)

        ## Finds ##
        self.btnAccountImage = self.findChild(QPushButton,'btnAccountImage')
        self.lblUsername = self.findChild(QLabel, 'lblUsername')
        self.lblUserNotFound = self.findChild(QLabel,'lblUserNotFound')
        self.leUsername = self.findChild(QLineEdit, 'leUsername')
        self.menubar = self.findChild(QMenuBar,'menubar')
        self.menubar.setStyleSheet("background: none;")
        self.menuPower = self.findChild(QMenu,'menuPower')
        self.actionEscape = self.findChild(QAction,'actionEscape')
        self.actionRestart = self.findChild(QAction, 'actionRestart')
        self.actionSuspend = self.findChild(QAction, 'actionSuspend')

        ## Get locale controls ##
        self.lc_suspend = control.read_record("suspend_action",
                                              "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_escape_action = control.read_record("btnEscape",
                                                    "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_power_menu = control.read_record("power_menu", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_restart_action = control.read_record("restart_action",
                                                     "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_font = control.read_record("font", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_menubar_direction = control.read_record("menubar_direction",
                                                        "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_lblUserNotFound = control.read_record("lblUserNotFound",
                                                      "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_lblUsername = control.read_record("lblUsername",
                                                  "/usr/share/locales/" + self.locale + "/desktop.locale")

        ## Font Size configure ##
        if self.fontsize == None:
            self.fontsize = 12
        else:
            self.fontsize = int(self.fontsize)

        ## Set layout direction

        if self.lc_menubar_direction == "rtl":
            self.menubar.setLayoutDirection(QtCore.Qt.RightToLeft)
        else:
            self.menubar.setLayoutDirection(QtCore.Qt.LeftToRight)

        ## Set locales all ##
        self.lblUsername.setText(self.lc_lblUsername)
        self.menuPower.setTitle(self.lc_power_menu)
        self.actionRestart.setText(self.lc_restart_action)
        self.actionEscape.setText(self.lc_escape_action)
        self.actionSuspend.setText(self.lc_suspend)

        ## Set fonts all ##
        self.lblUserNotFound.setFont (QFont(self.lc_font,self.fontsize))
        self.lblUsername.setFont(QFont(self.lc_font, self.fontsize))
        self.menubar.setFont(QFont(self.lc_font, self.fontsize))
        self.menuPower.setFont(QFont(self.lc_font, self.fontsize))
        self.actionSuspend.setFont(QFont(self.lc_font, self.fontsize))
        self.actionRestart.setFont(QFont(self.lc_font, self.fontsize))
        self.actionEscape.setFont(QFont(self.lc_font, self.fontsize))
        self.leUsername.setFont(QFont(self.lc_font, self.fontsize))

        ## Set Actions ##
        self.actionEscape.triggered.connect (self.escape_act)
        self.actionRestart.triggered.connect(self.restart_act)
        self.actionSuspend.triggered.connect(self.suspend_act)
        self.leUsername.returnPressed.connect(self.check_user) # https://pythonbasics.org/pyqt/ learn it

        ## PyCloud data
        self.cs = files.readall("/proc/info/cs")
        self.cd = files.readall("/proc/info/cd")
        self.ver = files.readall("/proc/info/ver")
        self.setWindowTitle(self.cs + " " + self.ver + " (" + self.cd + ")")

        ## Button Account Image
        self.userlogo = control.read_record("login.userlogo", "/etc/gui")
        if self.userlogo == None:
            self.userlogo = ""

        self.btnAccountImage.setStyleSheet("background-color: white;background-image: url(" + files.input(
            self.userlogo) + ");color: white;border-radius: 180% 180%;border-style: solid;border-width: 1%;border-color: blue;")

        ## Default bgcolor check ##
        bgcolor = control.read_record("login.bgcolor", "/etc/gui")
        background = control.read_record("login."+self.model+".background","/etc/gui")

        if not bgcolor == None:
            self.setStyleSheet("background-color: " + bgcolor + ";")
        elif not background == None:
            self.setStyleSheet("background-image: url(" + files.input(background) + ");")
        else:
            self.setStyleSheet("background-color: purple;")

        ## Show default ##
        if self.model == "1920x1080":
            self.showFullScreen()
        else:
            self.show()


w = MainApp()