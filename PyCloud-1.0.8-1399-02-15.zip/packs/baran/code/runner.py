from PyQt5 import QtWidgets, uic, QtCore, QtGui
import sys
from libcloud import core, app
from libnam import files, permissions

class MainApp(QtWidgets.QMainWindow):
    def clear_error (self):
        self.setStyleSheet("color: black;")
        self.lblExpRun.clear()
    def Run_act (self):
        ## Check the app is gui or cli ##

        argv = [self.leRun.text()]
        user = files.readall("/proc/info/su")

        exec = self.leRun.text()
        self.leRun.clear()
        app.system (exec)

        ## Check errors ##
        if files.isfile ("/tmp/fail"):
            files.remove ("/tmp/fail")
            self.lblExpRun.setText ("Cannot run {0} application not found.".replace("{0}",exec))
            self.lblExpRun.setStyleSheet ("color: red;")
        else:
            if files.isfile("/tmp/perm"):
                files.remove("/tmp/fail")
                self.lblExpRun.setText("Cannot run {0} application; Permission deind.".replace("{0}",exec))
                self.lblExpRun.setStyleSheet("color: red;")
            else:
                self.lblExpRun.clear()
                self.lblExpRun.setText ("{0} was runing successfully.".replace("{0}",exec))
                self.lblExpRun.setStyleSheet("color: green;")

        QtCore.QTimer.singleShot(3000,self.clear_error)
    def __init__(self):
        super(MainApp, self).__init__()
        uic.loadUi(files.input("/usr/share/widgets/runner.ui"),self)

        ## Find objects ##
        self.leRun = self.findChild(QtWidgets.QLineEdit,'leRun')
        self.lblExpRun = self.findChild(QtWidgets.QLabel,'lblExpRun')
        self.btnRun = self.findChild(QtWidgets.QPushButton,'btnRun')
        self.btnRun.clicked.connect(self.Run_act)
        self.show()