## Theme set ##

from libcloud import core
from libnam import colors, files
import sys

theme = "/usr/share/themes/"+sys.argv[0].replace(".","/")+".sa"
if files.isfile (theme):
    core.system ("saye "+theme)
else:
    colors.show ("tset","fail",sys.argv[0]+": theme not found")