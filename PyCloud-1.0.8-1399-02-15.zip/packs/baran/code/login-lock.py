from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files, control, permissions, process
from libcloud import core
import hashlib, importlib

from PyQt5 import QtCore, QtGui, QtWidgets

from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import uic
from libnam import files, control, process
import importlib, hashlib
from importlib import reload
from libcloud import core

from PyQt5 import QtCore, QtGui, QtWidgets

class MainApp (QMainWindow):
    fontsize = control.read_record("fontsize", "/etc/gui") # Get font size
    model = control.read_record("model", "/etc/gui") # Get screen model
    locale = control.read_record("locale","/etc/gui") # Get locale
    username = files.readall("/tmp/username.tmp") # Get username
    def suspend_act(self):
        import suspendpage
        w1 = suspendpage.w
        importlib.reload(suspendpage) ##https://www.geeksforgeeks.org/reloading-modules-python/
    def escape_act(self):
        core.shutdown()
        exit(0)
    def restart_act(self):
        core.reboot()
        exit(0)

    def desktop(self):
        self.close()
        import desktop
        w1 = desktop.w

    def check_password(self):
        self.password = self.lePassword.text()

        self.hashcode = hashlib.sha3_512(
            str(self.password).encode()).hexdigest()

        self.code = control.read_record("code", "/etc/users/" + self.username)

        if self.hashcode == self.code:
            self.close()
        else:
            self.lblWrongpassword.setText(self.lc_lblWrongpassword)
            QTimer.singleShot(1000, self.clear)

    ## Clear wrongs
    def clear(self):
        self.lblWrongpassword.clear()
        self.lePassword.clear()

    def __init__(self):
        super().__init__()

        ## Load ui ##
        uic.loadUi(files.input ('/usr/share/widgets/'+self.model+'/unlock.ui'),self)

        ## Frameless the window ##
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)

        ## Finds ##
        self.btnAccountImage = self.findChild(QPushButton,'btnAccountImage')
        self.lblPassword = self.findChild(QLabel, 'lblPassword')
        self.lblWrongpassword = self.findChild(QLabel,'lblWrongpassword')
        self.lePassword = self.findChild(QLineEdit, 'lePassword')

        ## Get locale controls ##
        self.lc_font = control.read_record("font", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_lblWrongpassword = control.read_record("lblWrongpassword",
                                                      "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_lblPassword = control.read_record("lblPassword",
                                                  "/usr/share/locales/" + self.locale + "/desktop.locale")

        ## Font Size configure ##
        if self.fontsize == None:
            self.fontsize = 12
        else:
            self.fontsize = int(self.fontsize)

        ## Set locales all ##
        self.lblPassword.setText(self.lc_lblPassword.replace("{0}",self.username))

        ## Set fonts all ##
        self.lblWrongpassword.setFont (QFont(self.lc_font,self.fontsize))
        self.lblPassword.setFont(QFont(self.lc_font, self.fontsize))
        self.lePassword.setFont(QFont(self.lc_font, self.fontsize))

        ## Echo Password ##
        self.lePassword.setEchoMode (QtWidgets.QLineEdit.Password)

        ## Set Actions ##
        self.lePassword.returnPressed.connect(self.check_password) # https://pythonbasics.org/pyqt/ learn it

        ## PyCloud data
        self.cs = files.readall("/proc/info/cs")
        self.cd = files.readall("/proc/info/cd")
        self.ver = files.readall("/proc/info/ver")
        self.setWindowTitle(self.cs + " " + self.ver + " (" + self.cd + ")")

        ## Button Account Image
        self.userlogo = control.read_record("login.userlogo", "/etc/gui")
        if self.userlogo == None:
            self.userlogo = ""

        self.btnAccountImage.setStyleSheet("background-color: white;background-image: url(" + files.input(
            self.userlogo) + ");color: white;border-radius: 180% 180%;border-style: solid;border-width: 1%;border-color: blue;")

        ## Default bgcolor check ##

        self.bgcolor = control.read_record("login.bgcolor", "/etc/users/" + self.username)
        if self.bgcolor == None:
            self.bgcolor = control.read_record("login.bgcolor", "/etc/gui")
        self.background = control.read_record("login." + self.model + ".background", "/etc/users/" + self.username)
        if self.background == None:
            self.background = control.read_record("login." + self.model + ".background", "/etc/gui")

        if not self.bgcolor == None:
            self.setStyleSheet("background-color: " + self.bgcolor + ";")
        elif not self.background == None:
            self.setStyleSheet("background-image: url(" + files.input(self.background) + ");")
        else:
            self.setStyleSheet("background-color: blue;")

        ## Show default ##
        if self.model == "1920x1080":
            self.showFullScreen()
        else:
            self.show()


w = MainApp()