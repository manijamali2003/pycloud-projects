from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files, control
from PyQt5 import uic

'''w = QWidget()


## Set UI ##

'''

class MainApp (QMainWindow):
    model = control.read_record("model", "/etc/gui") ## Get model control

    def login(self):
        self.close()
        self.type = control.read_record("login.type", "/etc/gui")
        if self.type == "default":
            import default
            w1 = default.w
        else:
            exit(0)

    def __init__(self):
        super().__init__()
        ## Load ui ##
        uic.loadUi(files.input('/usr/share/widgets/'+self.model+'/splash.ui'),self)

        ## PyCloud data ##
        self.cs = files.readall("/proc/info/cs")
        self.cd = files.readall("/proc/info/cd")
        self.ver = files.readall("/proc/info/ver")
        self.setWindowTitle(self.cs + " " + self.ver + " (" + self.cd + ")")
        self.setCursor(QCursor(Qt.BlankCursor))

        ## Get media ##
        self.bgcolor = control.read_record("splash.bgcolor", "/etc/gui")

        if not self.bgcolor == None:
            self.setStyleSheet("background-color: " + self.bgcolor + ";")

        self.background = control.read_record("splash." + self.model + ".background", "/etc/gui")

        if not self.background == None:
            self.setStyleSheet("background-image: url(" + files.input(self.background) + ");")

        ## Get timeout ##
        self.timeout = control.read_record("splash.timeout", "/etc/gui")
        if self.timeout == None:
            self.timeout = 3000
        else:
            self.timeout = int(self.timeout) * 1000

        QTimer.singleShot(self.timeout, self.login)

        ## Frameless the window ##
        self.setWindowFlags(Qt.FramelessWindowHint)

        ## Show screen ##
        if self.model == "1920x1080":
            self.showFullScreen()
        else:
            self.show()

w = MainApp()