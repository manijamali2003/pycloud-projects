import shutil, os, sys
from buildlibs import control

name = control.read_record("name","stor/etc/distro")
version = control.read_record("version","stor/etc/distro")
build = control.read_record("build","stor/etc/distro")

os.system ("\""+sys.executable+"\" build.py")

os.mkdir ("pack")
shutil.copytree ("app","pack/app")
shutil.copytree ("buildlibs","pack/buildlibs")
shutil.copytree ("config","pack/config")
shutil.copytree ("packs","pack/packs")
shutil.copyfile("build","pack/build")
shutil.copyfile("build.py","pack/build.py")
shutil.copyfile("build-config.py","pack/build-config.py")
shutil.copyfile("configure.py","pack/configure.py")
shutil.copyfile("install.py","pack/install.py")
shutil.copyfile("LICENSE","pack/LICENSE")
shutil.copyfile("run.py","pack/run.py")
shutil.copyfile("pack-release.py","pack/pack-release.py")
os.mkdir("pack/release")
os.mkdir("pack/build-packs")
os.mkdir("pack/stor")

shutil.make_archive("release/"+name+"-"+version+"-"+build,"zip","pack")
shutil.rmtree("pack")