
import sys, os, shutil

os.system ("\""+sys.executable+"\" build.py")
os.system ("\""+sys.executable+"\" configure.py")
os.system ("\""+sys.executable+"\" build-config.py")
os.system("\""+sys.executable+"\" -m pip install --upgrade pip setuptools")
os.system("\""+sys.executable+"\" -m pip install pyqt5")
os.system("\""+sys.executable+"\" -m pip install pyqtconsole")
os.system("\""+sys.executable+"\" -m pip install wget")