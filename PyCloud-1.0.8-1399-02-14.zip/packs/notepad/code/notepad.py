from PyQt5 import QtWidgets, uic
from libnam import files

class MainApp (QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()

        uic.loadUi(files.input ("/usr/share/widgets/notepad.ui"),self)