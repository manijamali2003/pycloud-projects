from PyQt5 import QtWidgets, uic, QtGui
import sys
from libcloud import core,app
from libnam import files

class MainApp(QtWidgets.QMainWindow):
    def new_act(self):
        self.textbox.clear()
        self.setWindowTitle("Untitled - Barge")

    def new_barge_act(self):
        app.system ("barge")

    def open_act(self):
        fileName = QtWidgets.QFileDialog()
        fileName.getOpenFileName(self,"Open Image", ".", "")


    def __init__(self):
        super(MainApp, self).__init__()
        uic.loadUi(files.input("/usr/share/widgets/barge.ui"),self)

        self.textbox = self.findChild(QtWidgets.QTextEdit,'textEdit')

        # File Actions ##
        self.new = self.findChild(QtWidgets.QAction,'actionNew')
        self.new_barge = self.findChild(QtWidgets.QAction, 'actionNew_Barge')
        self.open = self.findChild(QtWidgets.QAction, 'actionOpen')
        self.open.triggered.connect(self.open_act)
        self.save = self.findChild(QtWidgets.QAction, 'actionSave')
        self.save_as = self.findChild(QtWidgets.QAction, 'actionSave_As')
        self.exit = self.findChild(QtWidgets.QAction, 'actionExit')

        self.new.triggered.connect(self.new_act)
        self.exit.triggered.connect(exit)
        self.new_barge.triggered.connect(self.new_barge_act)
        self.show()