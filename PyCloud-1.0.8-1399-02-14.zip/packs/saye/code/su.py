import sys, hashlib, os,getpass
from libnam import files, colors, control
from libcloud import app

python = files.readall ("/proc/info/py")

def su (input_username,user):
    if files.isfile("/proc/selected"): files.remove("/proc/selected")
    if user == input_username:
        colors.show ("su","warning",user+" has already switched.")
    elif input_username=="guest":
        enable_cli = control.read_record("enable_cli", "/etc/guest")
        if enable_cli == "Yes":
            os.system(python + " vmnam.pyc user guest")
        else:
            colors.show(input_username, "fail", "user not found.")
    elif files.isfile ("/etc/users/"+input_username):
        hashname = hashlib.sha3_256(str(input_username).encode()).hexdigest()
        username = control.read_record("username","/etc/users/"+input_username)
        if hashname==username:
            input_password = app.codedialog ("Enter "+input_username+"'s password: ")
            hashcode = hashlib.sha3_512(str(input_password).encode()).hexdigest()
            password =  control.read_record("code","/etc/users/"+input_username)
            if hashcode == password:
                os.system(python+" vmnam.pyc user "+input_username+" "+input_password)
            else:
                colors.show("su", "fail", input_username + ": wrong password.")
        else:
            colors.show("su", "fail", input_username + " user not found.")
    else:
        colors.show ("su","fail",input_username+" user not found.")

if sys.argv==[]:
    colors.show("su", "fail", "no inputs.")
else:
    su (sys.argv[0],files.readall("/proc/info/su"))