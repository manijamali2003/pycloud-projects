# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'untitled.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from libnam import control, files
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import importlib
from libnam import modules, colors, permissions
from libcloud import app
import sys

mainApp = sys.argv[0]

class MainApp(QtWidgets.QMainWindow):
    ## Init ##
    def __init__(self):
        super().__init__()

        ## Get all databases ##
        self.default_icon = control.read_record("app.icon.default-icon", "/etc/gui")
        self.locale = control.read_record("locale", "/etc/gui")
        self.direction = control.read_record("direction", "/usr/share/locales/" + self.locale + "/app.locale")
        self.lc_font = control.read_record("font", "/usr/share/locales/" + self.locale + "/app.locale")
        self.lc_font_size = control.read_record("font_size", "/usr/share/locales/" + self.locale + "/app.locale")
        self.bgcolor = control.read_record("app.title.bgcolor", "/etc/gui")
        self.fgcolor = control.read_record("app.title.fgcolor", "/etc/gui")

        ## Frameless the window ##
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)

        ## MenuBar as TitleBar ##
        self.TitleBar = self.menuBar()
        self.TitleBar.setLayoutDirection(Qt.RightToLeft)

        if not self.bgcolor == None and not self.fgcolor == None:
            self.TitleBar.setStyleSheet("background-color: " + self.bgcolor + ";color: " + self.fgcolor + ";")
        elif not self.bgcolor == None:
            if self.bgcolor == "#FFFFFF" or self.bgcolor == "white":
                self.TitleBar.setStyleSheet("background-color: " + self.bgcolor + ";color: black;")
            else:
                self.TitleBar.setStyleSheet("background-color: " + self.bgcolor + ";color: white;")
        elif not self.fgcolor == None:
            self.TitleBar.setStyleSheet("background-color: #00BFFF;color: " + self.fgcolor)
        else:
            self.TitleBar.setStyleSheet("background-color: #00BFFF;color: white;")

        ## Three actions ##
        self.escape = QAction()
        self.max = QAction()
        self.min = QAction()

        ## Get icons ##
        if self.direction == "ltr":
            self.escapei = control.read_record("app.icon.escape-left", "/etc/gui")
        elif self.direction == "rtl":
            self.escapei = control.read_record("app.icon.escape-right", "/etc/gui")
        else:
            self.escapei = control.read_record("app.icon.escape-left", "/etc/gui")

        self.maxi = control.read_record("app.icon.max", "/etc/gui")
        self.mini = control.read_record("app.icon.min", "/etc/gui")

        ## Set icons ##
        self.escape.setIcon(QIcon(files.input(self.escapei)))
        self.max.setIcon(QIcon(files.input(self.maxi)))
        self.min.setIcon(QIcon(files.input(self.mini)))

        ## SEt triggereds ##

        self.escape.triggered.connect(exit)
        self.max.triggered.connect(self.max_act)
        self.min.triggered.connect(self.min_act)

        self.TitleBar.addAction(self.escape)
        self.TitleBar.addAction(self.max)
        self.TitleBar.addAction(self.min)

        ## TitleBar Widget ##
        self.title = QWidget()
        self.titlelayout = QHBoxLayout()
        self.ictitle = QLabel()

        if not self.default_icon == None:
            self.ictitle.setPixmap(QPixmap(files.input(self.default_icon)))
            self.ictitle.setFixedSize(25, 25)

        self.lbltitle = QLabel("")
        self.titlelayout.addWidget(self.lbltitle)
        self.titlelayout.addWidget(self.ictitle)
        self.title.setLayout(self.titlelayout)
        self.TitleBar.setCornerWidget(self.title)

        ## Configure direction ##
        if self.direction == "ltr":
            self.setLayoutDirection(Qt.LeftToRight)
            self.TitleBar.setLayoutDirection(Qt.RightToLeft)
        elif self.direction == "rtl":
            self.setLayoutDirection(Qt.RightToLeft)
            self.TitleBar.setLayoutDirection(Qt.LeftToRight)

        ## Configure Font ##
        if not self.lc_font == None:
            font = QFont()
            font.setFamily(self.lc_font)
            self.setFont(font)

        if not self.lc_font_size == None:
            font = QFont()
            font.setPointSize(int(self.lc_font_size))
            self.setFont(font)

        ## MainWindow = QtWidgets.QMainWindowWindow()
        self.module = modules.import_module(mainApp)
        self.MainWindow = self.module.MainApp()
        if not self.MainWindow.windowTitle()==None:
            self.lbltitle.setText(self.MainWindow.windowTitle())

        #self.lbltitle.setPixmap(QPixmap())
        ## Customize the window  (stackoverflow.com) ##

        self.w = self.MainWindow.width()
        self.h = self.MainWindow.height()
        self.resize(self.w, self.h)

        self.setMinimumSize(100, 100)
        self.setMaximumSize(1920, 1080)
        self.setCentralWidget(self.MainWindow)

        #QSizeGrip(self.MainWindow)

    maxc = False

    ## Actions ##
    def max_act(self):
        if self.maxc == False:
            self.resize(1920, 1080)
            self.maxc = True
        else:
            self.maxc = False
            self.resize(self.w, self.h)

    def min_act(self):
        self.close()

    ## Set Window Title instead of PyQt5 Window Title ##
    def SetWindowTitle(self, text):
        self.lbltitle.setText(text)

    ## Set Window Font ##
    def SetFontFamily(self, font):
        ft = QFont()
        ft.setFamily(self.font)
        self.setFont(ft)

    def SetFontSize(self, size):
        fts = QFont()
        fts.setPointSize(size)
        self.setFont(fts)

    def SetFont(self, font, size):
        ft = QFont()
        ft.setFamily(font)
        ft.setPointSize(size)
        self.setFont(ft)

    ## Disables and Enable three actions ##
    def EnableEscape(self):
        self.escape.setVisible(True)

    def EnableMinimize(self):
        self.min.setVisible(True)

    def EnableMaximize(self):
        self.max.setVisible(True)

    def DisableEscape(self):
        self.escape.setVisible(False)

    def DisableMinimize(self):
        self.min.setVisible(False)

    def DisableMaximize(self):
        self.max.setVisible(False)

    ## Resize ##
    def Resize(self, w, h):
        self.w = w
        self.h = h
        self.resize(self.w, self.h)

    ## FixedSize ##
    def SetFixedSize(self, w, h):
        self.w = w
        self.h = h
        self.setFixedSize(self.w, self.h)

    ## Maximum Size ##
    def SetMaximumSize(self, w, h):
        self.w = w
        self.h = h
        self.setMaximumSize(w, h)

    ## Minimum Size ##
    def SetMinimumSize(self, w, h):
        self.w = w
        self.h = h
        self.setMinimumSize(w, h)

    ## Set Width ##
    def SetWidth(self, w):
        self.w = w
        self.resize(self.w, self.h)

    ## Set Height ##
    def SetHeight(self, h):
        self.h = h
        self.resize(self.w, self.h)

    ## Set Fixed Width ##
    def SetFixedWidth(self, w):
        self.w = w
        self.setFixedWidth(self.w)

    ## Set Fixed Height ##
    def SetFixedHeight(self, h):
        self.h = h
        self.setFixedHeight(self.h)

    ## Set Maximums ##
    def SetMaximumWidth(self, w):
        self.setMaximumWidth(w)

    def SetMaximumHeight(self, h):
        self.setMaximumHeight(h)

    def SetMinimumWidth(self, w):
        self.setMinimumWidth(w)

    def SetMinimumHeight(self, h):
        self.setMinimumHeight(h)

    ## Set Window Title Color ##
    def SetWindowTitleColor(self, bgcolor, fgcolor):
        self.TitleBar.setStyleSheet("background-color: " + bgcolor + ";color: " + fgcolor + ";")

    ## Set Main Window Back Color ##
    def SetBackColor(self, color):
        self.backcolor = color
        self.MainWindow.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Set Main Window Fore Color ##
    def SetForeColor(self, color):
        self.forecolor = color
        self.MainWindow.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Set Main Window Color ##
    def SetColor(self, bgcolor, fgcolor):
        self.backcolor = bgcolor
        self.forecolor = fgcolor
        self.MainWindow.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Customize the window  (stackoverflow.com) ##
    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.__press_pos = event.pos()

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.__press_pos = None

    def mouseMoveEvent(self, event):
        if self.__press_pos:
            self.move(self.pos() + (event.pos() - self.__press_pos))

## Databases ##
user = files.readall("/proc/info/su")
argv = sys.argv

## Create id #
if not app.chid ("app"): app.cid ("app")

## EXEC part ##
if argv[0].__contains__("/"):
    if files.isfile(argv[0] + ".pyc"):
        if permissions.check(files.output(argv[0]) + ".pyc", "x", user):
            sys.argv = argv[1:]
            app = QtWidgets.QApplication(sys.argv)
            w = MainApp()
            mainApp = argv[0]
            w.show()
            app.exec_()
            exit(0)
        else:
            colors.show(argv[0], "perm", "")
            files.create ("/tmp/perm")
            exit(0)
    else:
        colors.show(argv[0], "fail", "command not found.")
        files.create("/tmp/fail")
else:
    if files.isfile("/usr/bin/" + argv[0] + ".pyc"):
        if permissions.check("/usr/bin/" + files.output(argv[0]) + ".pyc", "x", user):
            sys.argv = argv[1:]
            app = QtWidgets.QApplication(sys.argv)
            w = MainApp()
            w.show()
            app.exec_()
            exit(0)
        else:
            colors.show(argv[0], "perm", "")
            files.create("/tmp/perm")
            exit(0)
    else:
        colors.show(argv[0], "fail", "command not found.")
        files.create("/tmp/fail")

## End ##
app.kid ("app")