from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files, control, permissions
from libcloud import core
import hashlib, importlib

from PyQt5 import QtCore, QtGui, QtWidgets, uic

'''
class Ui_MainWindow(object):
    
    
    def setupUi(self, MainWindow):
        
        ## Menu bar design
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1920, 1080)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.btnUnlock = QtWidgets.QPushButton(self.centralwidget)
        self.btnUnlock.setGeometry(QtCore.QRect(0, 0, 1920, 1080))
        self.btnUnlock.setCursor(QtGui.QCursor(QtCore.Qt.BlankCursor))
        self.btnUnlock.setStyleSheet("background-color: black;")
        self.btnUnlock.setText("")
        self.btnUnlock.setAutoRepeat(False)
        self.btnUnlock.setAutoExclusive(False)
        self.btnUnlock.setObjectName("btnUnlock")

        self.btnUnlock.clicked.connect (self.btnUnlock_click)

        MainWindow.setCentralWidget(self.centralwidget)

        ## Get username database

        self.username = files.readall("/tmp/username.tmp")

        ## Get distro database
        self.cs = files.readall("/proc/info/cs")
        self.cd = files.readall("/proc/info/cd")
        self.ver = files.readall("/proc/info/ver")
        MainWindow.setWindowTitle(self.cs + " " + self.ver + " (" + self.cd + ")")

        ## Get locale database
        self.locale = control.read_record("locale", "/etc/gui")
        if self.locale == None: self.locale = "English"

        ## Locale section

        self.lc_font = control.read_record("font", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_guest = control.read_record("guest", "/usr/share/locales/" + self.locale + "/desktop.locale")


        ## Set name ##
        if self.username=="guest":
            self.name = self.lc_guest
        else:
            first_name = control.read_record("first_name", "/etc/users/" + self.username)
            last_name = control.read_record("last_name", "/etc/users/" + self.username)
            if not first_name == None and not last_name == None:
                self.name = first_name + " " + last_name
            elif not first_name == None:
                self.name = first_name
            elif not last_name == None:
                self.name = last_name
            else:
                self.name = self.username

        ## Set font ##
        font = QFont()
        font.setFamily(self.lc_font)
        MainWindow.setFont(font)

        ## Default bgcolor check ##
        bgcolor = None
        if not self.username == "guest":
            bgcolor = control.read_record("lock.bgcolor", "/etc/users/" + self.username)
        if bgcolor == None:
            bgcolor = control.read_record("lock.bgcolor", "/etc/gui")
        background = None
        if not self.username == "guest":
            background = control.read_record("lock."+self.model+".background", "/etc/users/" + self.username)
        if background == None:
            background = control.read_record("lock."+self.model+".background", "/etc/gui")

        if not bgcolor == None:
            self.btnUnlock.setStyleSheet("background-color: " + bgcolor + ";")
        elif not background==None:
            self.btnUnlock.setStyleSheet("background-image: url(" + files.input(background) + ");")
        else:
            self.btnUnlock.setStyleSheet("background-color: blue;")


        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))


MainWindow = QtWidgets.QMainWindow()
w = Ui_MainWindow()
w.setupUi(MainWindow)
MainWindow.showFullScreen()'''

class MainApp (QtWidgets.QMainWindow):
    model = control.read_record("model", "/etc/gui")
    fontsize = control.read_record("fontsize", "/etc/gui")
    username = files.readall("/tmp/username.tmp")

    def unlock(self):
        import unlock
        importlib.reload(unlock)
        w1 = unlock.w

    def unlock_act(self):
        self.close()
        if not self.username == "guest":
            self.unlock()

    def __init__(self):
        super().__init__()

        ## Load ui ##
        uic.loadUi(files.input('/usr/share/widgets/' + self.model + '/lock.ui'), self)

        # Finds #
        self.btnUnlock = self.findChild(QtWidgets.QPushButton,'btnUnlock')

        ## Font Size configure ##
        if self.fontsize == None:
            self.fontsize = 12
        else:
            self.fontsize = int(self.fontsize)

        # Unlock action #
        self.btnUnlock.clicked.connect(self.unlock_act)

        ## Get distro database
        self.cs = files.readall("/proc/info/cs")
        self.cd = files.readall("/proc/info/cd")
        self.ver = files.readall("/proc/info/ver")
        self.setWindowTitle(self.cs + " " + self.ver + " (" + self.cd + ")")

        ## Default bgcolor check ##
        self.bgcolor = None
        if not self.username == "guest":
            self.bgcolor = control.read_record("unlock.bgcolor", "/etc/users/" + self.username)
        if self.bgcolor == None:
            self.bgcolor = control.read_record("unlock.bgcolor", "/etc/gui")
        self.background = None
        if not self.username == "guest":
            self.background = control.read_record("unlock." + self.model + ".background", "/etc/users/" + self.username)
        if self.background == None:
            self.background = control.read_record("unlock." + self.model + ".background", "/etc/gui")

        if not self.bgcolor == None:
            self.btnUnlock.setStyleSheet("background-color: " + self.bgcolor + ";")
        elif not self.background == None:
            self.btnUnlock.setStyleSheet("background-image: url(" + files.input(self.background) + ");")
        else:
            self.btnUnlock.setStyleSheet("background-color: blue;")

        ## Show lock ##
        if self.model == "x19":
            self.showFullScreen()
        else:
            self.show()

w = MainApp()