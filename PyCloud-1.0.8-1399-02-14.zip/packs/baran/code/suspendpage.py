# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'suspend.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!

from libnam import control
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    model = control.read_record("model", "/etc/gui")

    def btnEscape_suspendpage_click(self):
        MainWindow.close()

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.btnSleep = QtWidgets.QPushButton(self.centralwidget)
        self.btnSleep.setGeometry(QtCore.QRect(0, 0, 1920, 1080))
        self.btnSleep.setCursor(QtGui.QCursor(QtCore.Qt.BlankCursor))
        self.btnSleep.setStyleSheet("background-color: black;")
        MainWindow.setStyleSheet("background-color: black;")
        self.btnSleep.setText("")
        self.btnSleep.setAutoRepeat(False)
        self.btnSleep.setAutoExclusive(False)
        self.btnSleep.setObjectName("btnSleep")
        MainWindow.setCentralWidget(self.centralwidget)

        self.btnSleep.clicked.connect (self.btnEscape_suspendpage_click)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))

MainWindow = QtWidgets.QMainWindow()
w = Ui_MainWindow()
w.setupUi(MainWindow)
MainWindow.showFullScreen()
