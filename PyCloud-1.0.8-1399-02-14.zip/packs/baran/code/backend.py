from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files,control

app = QApplication([])
w = QWidget()
cs = files.readall ("/proc/info/cs")
cd = files.readall ("/proc/info/cd")
ver = files.readall ("/proc/info/ver")
w.setWindowTitle(cs+" "+ver+" ("+cd+")")

model = control.read_record ("model","/etc/gui")

def splash():
    import splash
    w1 = splash.w

if model=="x19":



    bgcolor = control.read_record ("backend.bgcolor","/etc/gui")

    if bgcolor == None:
        bgcolor = "#000000"

    w.setStyleSheet("background-color: "+bgcolor+";")
    w.setCursor(QCursor(Qt.BlankCursor))

    QTimer.singleShot(0,splash)

    w.showFullScreen()
else:
    w.hide()
    QTimer.singleShot(0, splash)
app.exec_()