from libnam import process, files, permissions, colors, control
import os, importlib, getpass

## Graphical application library ##

## Run app ##
def system (cmd):
    os.system (files.readall ("/proc/info/py")+" vmnam.pyc exec app "+cmd)

## Create id ##
def cid (id):
    if files.isfile ("/proc/id/"+id):
        colors.show("libcloud.app.cid", "fail", id+": id has already exists.")
    else:
        files.create ("/proc/id/"+id)

## Kill id ##
def kid (id):
    if not files.isfile ("/proc/id/"+id):
        colors.show("libcloud.app.kid", "fail", id+": id not found.")
    else:
        files.remove ("/proc/id/"+id)

## Check id ##
def chid (id):
    if files.isfile("/proc/id/"+id):
        return True
    else:
        return False

## Input Dialogs ##
def inputdialog (output):
    files.write("/tmp/input-title", output)
    system("inputdialog")
    files.remove("/tmp/input-title")

    if files.isfile("/tmp/input"):
        strv = files.readall("/tmp/input")
        files.remove("/tmp/input")
        return strv
    else:
        return ""

def codedialog (output):
    files.write("/tmp/input-title", output)
    system("codedialog")
    files.remove("/tmp/input-title")

    if files.isfile("/tmp/input"):
        strv = files.readall("/tmp/input")
        files.remove("/tmp/input")
        return strv
    else:
        return ""

## Message Box ##

def messagebox (message):
    files.write("/tmp/messagebox",message)
    system("messagebox")
    files.remove ("/tmp/messagebox")