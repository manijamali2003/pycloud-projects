import sys, os, hashlib
from libnam import files, control, permissions, colors, process

def shutdown ():
    if files.isdir("/desk/guest"):
        files.removedirs("/desk/guest")
    if files.isdir ("/tmp"):
        files.removedirs("/tmp")
        files.mkdir ("/tmp")
    if files.isfile("/proc/selected"): files.remove("/proc/selected")
    process.endall()

shutdown()
