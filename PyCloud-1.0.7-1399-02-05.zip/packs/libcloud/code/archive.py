
from libnam import files, control, colors, permissions
import shutil

## Zip compresser ##
def zip (src,dest):
    su = files.readall("/proc/info/su") ## Get user data base
    if permissions.check (files.output(src),"r",su): ## Check this user permissions
        if permissions.check (files.output(dest+".zip"),"r",su): ## Check read only permission
            if files.isdir (src): ## Check source dir exists
                if files.isdir (dest+".zip"): ## Check dest dir exists
                    colors.show("libcloud.archive.zip", "fail", dest+".zip" + ": dest is a directory.")
                else:
                    shutil.make_archive(files.input(dest),"zip",files.input(src)) ## Create archive
            elif files.isfile (src):
                colors.show("libcloud.archive.zip", "fail",src+ ": source is a file.") ## Show error for permissions
            else:
                colors.show("libcloud.archive.zip", "fail",src+ ": source not found.")
        else:
            colors.show("libcloud.archive.zip", "perm", "")
    else:
        colors.show ("libcloud.archive.zip","perm","")

## Tarball compresser ##
def tarball (src,dest):
    su = files.readall("/proc/info/su")
    if permissions.check (files.output(src),"r",su):
        if permissions.check (files.output(dest+".tar"),"r",su):
            if files.isdir (src):
                if files.isdir (dest+".tar"):
                    colors.show("libcloud.archive.tarball", "fail", dest+".tar" + ": dest is a directory.")
                else:
                    shutil.make_archive(files.input(dest),"tar",files.input(src))
            elif files.isfile (src):
                colors.show("libcloud.archive.tarball", "fail",src+ ": source is a file.")
            else:
                colors.show("libcloud.archive.tarball", "fail",src+ ": source not found.")
        else:
            colors.show("libcloud.archive.tarball", "perm", "")
    else:
        colors.show ("libcloud.archive.tarball","perm","")


## XZip compresser ##
def xzip(src, dest):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(src), "r", su):
        if permissions.check(files.output(dest + ".xz"), "r", su):
            if files.isdir(src):
                if files.isdir(dest + ".xz"):
                    colors.show("libcloud.archive.xzip", "fail", dest + ".xz" + ": dest is a directory.")
                else:
                    shutil.make_archive(files.input(dest), "xz", files.input(src))
            elif files.isfile(src):
                colors.show("libcloud.archive.xzip", "fail", src + ": source is a file.")
            else:
                colors.show("libcloud.archive.xzip", "fail", src + ": source not found.")
        else:
            colors.show("libcloud.archive.xzip", "perm", "")
    else:
        colors.show("libcloud.archive.xzip", "perm", "")

## GZip compresser ##
def gzip(src, dest):
    su = files.readall("/proc/info/su")
    if permissions.check(files.output(src), "r", su):
        if permissions.check(files.output(dest + ".gz"), "r", su):
            if files.isdir(src):
                if files.isdir(dest + ".gz"):
                    colors.show("libcloud.archive.xzip", "fail", dest + ".gz" + ": dest is a directory.")
                else:
                    shutil.make_archive(files.input(dest), "gz", files.input(src))
            elif files.isfile(src):
                colors.show("libcloud.archive.gzip", "fail", src + ": source is a file.")
            else:
                colors.show("libcloud.archive.gzip", "fail", src + ": source not found.")
        else:
            colors.show("libcloud.archive.gzip", "perm", "")
    else:
        colors.show("libcloud.archive.gzip", "perm", "")

