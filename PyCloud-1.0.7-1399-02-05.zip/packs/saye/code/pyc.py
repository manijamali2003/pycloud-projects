import sys, os, hashlib
from libnam import files, control, permissions, colors, process

def pyc (option,src,dest):
    if option=="":
        if permissions.check (files.output(src),"r",files.readall("/proc/info/su")):
            if permissions.check (files.output(src.replace(".py",".pyc")),"w",files.readall("/proc/info/su")):
                files.compile (src,src.replace(".py",".pyc"))
            else:
                colors.show ("pyc","perm","")
        else:
            colors.show("pyc", "perm", "")
    elif option=="-c":
        if permissions.check (files.output(src),"r",files.readall("/proc/info/su")):
            if permissions.check (files.output(dest),"w",files.readall("/proc/info/su")):
                files.compile(src,dest)
            else:
                colors.show("pyc", "perm", "")
        else:
            colors.show("pyc", "perm", "")
    else:
        colors.show ("pyc","fail","option not found.")

cmdln = ['']
cmdln[1:] = sys.argv

if not cmdln[1:] == []:
    if cmdln[2:] == []:
        pyc("", cmdln[1], "")
    else:
        if cmdln[3:] == []:
            colors.show("pyc", "fail", "no inputs.")
        else:
            pyc(cmdln[1], cmdln[2], cmdln[3])
else:
    colors.show("pyc", "fail", "no inputs.")