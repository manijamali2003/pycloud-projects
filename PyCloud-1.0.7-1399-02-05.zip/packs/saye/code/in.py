import sys, os, hashlib
from libnam import files, control, permissions, colors, process

def set (name,value):
    select = files.readall("/proc/info/sel")
    if not select.startswith ("/proc/"):
        if permissions.check(files.output(select),"w",files.readall("/proc/info/su")):
            control.write_record(name, value, select)
        else:
            colors.show ("set","perm","")
    else:
        control.write_record(name,value,select)

def _in (name):
    set (name,input())

if not sys.argv == []:
    _in(sys.argv[0])
else:
    colors.show("in", "fail", "no inputs.")