import sys, os, hashlib
from libnam import files, control, permissions, colors, process

def getv ():
    select = files.readall("/proc/info/sel")
    if not select.startswith ("/proc/"):
        if permissions.check(files.output(select),"w",files.readall("/proc/info/su")):
            listinfo = files.list("/proc/info")
            for i in listinfo:
                control.write_record(i, files.readall("/proc/info/" + i), select)
        else:
            colors.show ("getv","perm","")
    else:
        listinfo = files.list ("/proc/info")
        for i in listinfo:
            control.write_record(i,files.readall("/proc/info/"+i),select)

getv()