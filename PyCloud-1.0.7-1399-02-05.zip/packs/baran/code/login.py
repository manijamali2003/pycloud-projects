from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files,control

app = QApplication([])
w = QWidget()
cs = files.readall ("/proc/info/cs")
cd = files.readall ("/proc/info/cd")
ver = files.readall ("/proc/info/ver")
w.setWindowTitle(cs+" "+ver+" ("+cd+")")

def x19_login():
    w.close()
    type = control.read_record("login.type", "/etc/gui")
    if type == "default":
        from x19.login import default
        w1 = default.w
    else:
        exit(0)

bgcolor = control.read_record ("backend.bgcolor","/etc/gui")
model = control.read_record ("model","/etc/gui")

if bgcolor==None:
    bgcolor = "#000000"
w.setStyleSheet("background-color: "+bgcolor+";")
w.setCursor(QCursor(Qt.BlankCursor))

if model=="x19":
    QTimer.singleShot(0,x19_login)
else:
    exit(0)

w.showFullScreen()
app.exec_()