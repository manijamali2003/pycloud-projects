from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files, control

w = QWidget()
cs = files.readall("/proc/info/cs")
cd = files.readall("/proc/info/cd")
ver = files.readall("/proc/info/ver")
w.setWindowTitle(cs + " " + ver + " (" + cd + ")")
w.setWindowFlags(Qt.FramelessWindowHint)
w.setCursor(QCursor(Qt.BlankCursor))
w.resize(1920,1080)
bgcolor = control.read_record("splash.bgcolor","/etc/gui")

model = control.read_record ("model","/etc/gui")

def x19_login():
    w.close()
    type = control.read_record("login.type", "/etc/gui")
    if type == "default":
        from x19.login import default
        w1 = default.w
    else:
        exit(0)

if not bgcolor==None:
    w.setStyleSheet("background-color: "+bgcolor+";")

background = control.read_record("splash.x19.background","/etc/gui")

if not background==None:
    w.setStyleSheet("background-image: url("+files.input(background)+");")

timeout = control.read_record("splash.timeout", "/etc/gui")
if timeout == None:
    timeout = 3000
else:
    timeout = int(timeout) * 1000

if model == "x19":
    QTimer.singleShot(timeout, x19_login)
else:
    exit(0)

w.showFullScreen()
