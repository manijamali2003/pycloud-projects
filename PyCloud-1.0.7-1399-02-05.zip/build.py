from buildlibs import pack_archives as pack
import shutil, os

shutil.rmtree("stor")
os.mkdir ("stor")
os.mkdir ("stor/app")
os.mkdir ("stor/app/packages")

pack.build ("namnam")
pack.build ("baran")
pack.build ("paye")
pack.build ("saye")
pack.build ("libcloud")
pack.build ("barge")

pack.unpack ("namnam")
pack.unpack ("baran")
pack.unpack ("paye")
pack.unpack ("saye")
pack.unpack ("libcloud")
pack.unpack ("barge")
