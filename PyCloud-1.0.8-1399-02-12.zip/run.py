import os,sys

os.system ("\""+sys.executable+"\" build.py")
os.system ("cd stor && \""+sys.executable+"\" vmnam.pyc user root toor")
