import sys, os, hashlib
from libnam import files, control, permissions, colors, process

def cp (src,dest):
    ## check src ##
    if files.isdir (src):
        if files.isfile (dest):
            colors.show("cp", "fail", dest + ": dest is a file.")
        else:
            if permissions.check(files.output(src), "r",files.readall ("/proc/info/su")):
                if permissions.check(files.output(dest), "w", files.readall ("/proc/info/su")):
                    perm = permissions.get_permissions(files.output(src))
                    control.write_record(files.output(dest), perm, "/etc/permtab")
                    files.copydir (src,dest)
                else:
                    colors.show ("cp","perm","")
            else:
                colors.show("cp","perm","")
    elif files.isfile (src):
        if files.isdir (dest):
            colors.show("cp", "fail", dest + ": dest is a directory.")
        else:
            if permissions.check(files.output(src), "r", files.readall ("/proc/info/su")):
                if permissions.check(files.output(dest), "w", files.readall ("/proc/info/su")):
                    perm = permissions.get_permissions(files.output(src))
                    control.write_record(files.output(dest), perm, "/etc/permtab")
                    files.copy (src,dest)
                else:
                    colors.show ("cp","perm","")
            else:
                colors.show ("cp","perm","")
    else:
        colors.show ("cp","fail",src+": source not found.")

cmdln = ['']
cmdln[1:] = sys.argv

if cmdln[1:] == []:
    colors.show("cp", "fail", "no inputs.")
else:
    if cmdln[2:] == []:
        colors.show("cp", "fail", "no inputs.")
    else:
        cp(cmdln[1], cmdln[2])