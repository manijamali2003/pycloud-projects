import  requests, sys, os
from libnam import files, permissions, colors

r = requests.get(sys.argv[0])
if permissions.check(files.output(sys.argv[1]), "w", files.readall ("/proc/info/su")):
    with open(files.input(sys.argv[1]), "wb") as code:
        code.write(r.content)
else:
    colors.show ("wget","perm","")