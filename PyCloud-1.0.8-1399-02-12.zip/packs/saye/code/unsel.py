import sys, os, hashlib
from libnam import files, control, permissions, colors, process

def unsel ():
    select = files.readall("/proc/info/sel")
    if select == "/proc/"+files.readall("/proc/info/sp"):
        colors.show ("unsel","warning","controller has already selected.")
    else:
        files.write("/proc/info/sel", "/proc/"+files.readall("/proc/info/sp"))
        if files.isfile ("/proc/selected"): files.remove("/proc/selected")

unsel()