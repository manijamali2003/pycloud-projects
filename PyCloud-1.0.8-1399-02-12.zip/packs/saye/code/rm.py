import sys, os, hashlib
from libnam import files, control, permissions, colors, process

## @commands/rm ##

def rm (names):
    for i in names:
        if files.isdir (i):
            if permissions.check(files.output(i), "w", files.readall ("/proc/info/su")):
                files.removedirs(i)
            else:
                colors.show ("rm","perm","")
                exit(0)
        elif files.isfile (i):
            if permissions.check(files.output(i), "w", files.readall ("/proc/info/su")):
                files.remove(i)
            else:
                colors.show ("rm","perm","")
                exit(0)
        else:
            colors.show("rm", "fail", i + ": file or directory not found.")
            exit(0)

rm(sys.argv)