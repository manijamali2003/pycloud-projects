from PyQt5 import QtWidgets, uic, QtCore, QtGui
import sys
from libcloud import core, app
from libnam import files, permissions

class MainApp(QtWidgets.QMainWindow):

    def __init__(self):
        super(MainApp, self).__init__()
        uic.loadUi(files.input("/usr/share/widgets/messagebox.ui"),self)

        ## finds ##
        self.lblmessage = self.findChild(QtWidgets.QLabel,'lblMessage')
        self.lblmessage.setText(files.readall("/tmp/messagebox")) # Show message
        self.btnOK = self.findChild(QtWidgets.QPushButton, 'btnOK')

        ## Clicks ##
        self.btnOK.clicked.connect (exit)

        self.show()