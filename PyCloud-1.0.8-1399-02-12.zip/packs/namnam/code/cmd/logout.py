
import sys, os, hashlib
from libnam import files, control, permissions, colors, process

python = files.readall ("/proc/info/py")
def logout():
    if files.isfile("/proc/selected"): files.remove("/proc/selected")
    process.endall()
    os.system(python + " vmnam.pyc login")

logout()