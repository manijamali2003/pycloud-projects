import sys, os, hashlib
from libnam import files, control, permissions, colors, process

python = files.readall ("/proc/info/py")

def new (user,code):
    if files.isfile("/proc/selected"): files.remove("/proc/selected")
    if user=="guest":
        os.system(python+" vmnam.pyc user guest")
    else:
        os.system(python+" vmnam.pyc user "+user+" "+code)

new (control.read_record ("username","/tmp/su.tmp"),control.read_record ("code","/tmp/su.tmp"))
if files.isfile ("/tmp/su.tmp"): files.remove ("/tmp/su.tmp")