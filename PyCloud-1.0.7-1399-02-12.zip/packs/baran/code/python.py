import sys
from threading import Thread
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from pyqtconsole.console import PythonConsole
from libnam import files

import pyqtconsole.highlighter as hl

console = PythonConsole(formats={
    'keyword':    hl.format('blue', 'bold'),
    'operator':   hl.format('red'),
    'brace':      hl.format('darkGray'),
    'defclass':   hl.format('black', 'bold'),
    'string':     hl.format('magenta'),
    'string2':    hl.format('darkMagenta'),
    'comment':    hl.format('darkGreen', 'italic'),
    'self':       hl.format('black', 'italic'),
    'numbers':    hl.format('brown'),
    'inprompt':   hl.format('darkBlue', 'bold'),
    'outprompt':  hl.format('darkRed', 'bold'),
})

class MainApp (PythonConsole):
    def __init__(self):
        super(MainApp,self).__init__()
        self.show()

        self.setWindowTitle("Python shell")
        self.setWindowIcon(QIcon(files.input("/usr/share/icons/128x128/shell.svg")))
        #self.eval_in_thread()