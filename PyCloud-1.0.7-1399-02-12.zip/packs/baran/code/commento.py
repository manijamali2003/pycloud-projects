# very basic terminal emulator in pyqt
# https://pythonbasics.org/pyqt/

from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtWidgets import QMessageBox, QDialog, QFileDialog
import sys
import os
from libnam import files, control
import subprocess


class MainApp(QtWidgets.QMainWindow):
    def __init__(self):
        super(MainApp, self).__init__()
        uic.loadUi(files.input('/usr/share/widgets/commento.ui'), self)
        self.lineEdit.returnPressed.connect(self.doCMD)
        # self.pushButtonInstall.clicked.connect(self.onClick)
        self.working_dir = "."

    def doCMD(self):

        cmd = self.lineEdit.text()
        self.lineEdit.setText("")

        ## Database ##

        self.user = files.readall("/proc/info/su")
        self.hostname = files.readall("/proc/info/host")
        self.show_username = control.read_record("show_username", "/etc/prompt")
        self.show_hostname = control.read_record("show_hostname", "/etc/prompt")
        self.show_path = control.read_record("show_path", "/etc/prompt")
        self.root_symbol = control.read_record("root", "/etc/prompt")
        self.user_symbol = control.read_record("user", "/etc/prompt")

        ## Setting up prompt data base 2 ##

        self.color_uh = ""
        self.color_path = ""
        self.prompt_symbol = ""

        if self.user == "root":
            self.prompt_symbol = self.root_symbol
            self.color_uh = "white"
            self.color_path = "white"
        else:
            self.prompt_symbol = self.user_symbol
            self.color_uh = "green"
            self.color_path = "blue"

        ## Setting up space of prompt ##

        if self.show_username == "Yes":
            self.space_username = self.user
        else:
            self.space_username = ""

        if self.show_hostname == "Yes":
            self.space_hostname = self.hostname
        else:
            self.space_hostname = ""

        if self.show_path == "Yes":
            self.space_path = files.readall("/proc/info/pwd")
        else:
            space_path = ""

        if self.show_hostname == "Yes" and self.show_username == "Yes":
            self.space1 = "@"
        else:
            self.space1 = ""

        if (self.show_hostname == "Yes" or self.show_username == "Yes") and self.show_path == "Yes":
            self.space2 = ":"
        else:
            self.space2 = ""

        if "cd " in cmd:
            vals = cmd.split(" ")

            ###########

            if vals[1][0] == "/":
                self.working_dir = vals[1]
            else:
                self.working_dir = self.working_dir + "/" + vals[1]

            print(self.working_dir)

            subprocess.call("python vmnam.pyc exec "+cmd, shell=True, cwd=self.working_dir)

            self.textBrowser.setText(self.textBrowser.toPlainText() + "\n$ " + cmd)
        else:
            result = subprocess.check_output("python vmnam.pyc exec "+cmd, shell=True, cwd=self.working_dir)
            if result.decode("utf-8")=="":
                output = ""
            else:
                output = "\n"+result.decode("utf-8")
            self.textBrowser.setText(self.textBrowser.toPlainText() + "\n "+self.user + self.space1 + self.space_hostname  + self.space2 + self.space_path + self.prompt_symbol + " "+ cmd + ""+output)

        self.textBrowser.verticalScrollBar().setValue(self.textBrowser.verticalScrollBar().maximum())

    # def onClick(self):
    #    if len(self.lineEditName.text()) < 1:
    #        QMessageBox.critical(self, "Install", "Install")
    #    else:
    #        os.system("sudo apt-get install " + self.lineEditName.text())

'''
## Prompt data base ##

        show_username = control.read_record("show_username", "/etc/prompt")
        show_hostname = control.read_record("show_hostname", "/etc/prompt")
        show_path = control.read_record("show_path", "/etc/prompt")
        root_symbol = control.read_record("root","/etc/prompt")
        user_symbol = control.read_record("user", "/etc/prompt")

        ## Setting up prompt data base 2 ##

        color_uh = ""
        color_path = ""
        prompt_symbol = ""

        if user=="root":
            prompt_symbol = root_symbol
            color_uh = colors.get_colors()
            color_path = colors.get_colors()
        else:
            prompt_symbol = user_symbol
            color_uh = colors.get_ok()
            color_path = colors.get_path()

        ## Setting up space of prompt ##

        if show_username == "Yes":
            space_username = user
        else:
            space_username = ""

        if show_hostname == "Yes":
            space_hostname = hostname
        else:
            space_hostname = ""

        if show_path == "Yes":
            space_path = files.readall("/proc/info/pwd")
        else:
            space_path = ""

        if show_hostname == "Yes" and show_username == "Yes":
            space1 = "@"
        else:
            space1 = ""

        if (show_hostname == "Yes" or show_username == "Yes") and show_path == "Yes":
            space2 = ":"
        else:
            space2 = ""

        ## Shell prompt ##

        cmd = input(color_uh + space_username + space1 + space_hostname + colors.get_colors() + space2 + color_path + space_path + colors.get_colors() + prompt_symbol + " ")
'''