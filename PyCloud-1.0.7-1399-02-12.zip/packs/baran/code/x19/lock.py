from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files, control, permissions
from libcloud import core
import hashlib, importlib

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    model = control.read_record("model","/etc/gui")
    fontsize = control.read_record("fontsize", "/etc/gui")
    def x19_unlock(self):
        from x19 import unlock
        importlib.reload(unlock)
        w1 = unlock.w
    def btnUnlock_click(self):
        MainWindow.close()
        if not self.username=="guest":
            if self.model == "x19":
                self.x19_unlock()
            else:
                exit(0)
    def setupUi(self, MainWindow):
        ## Font Size configure ##
        if self.fontsize == None:
            self.fontsize = 12
        else:
            self.fontsize = int(self.fontsize)
        ## Menu bar design
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1920, 1080)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.btnUnlock = QtWidgets.QPushButton(self.centralwidget)
        self.btnUnlock.setGeometry(QtCore.QRect(0, 0, 1920, 1080))
        self.btnUnlock.setCursor(QtGui.QCursor(QtCore.Qt.BlankCursor))
        self.btnUnlock.setStyleSheet("background-color: black;")
        self.btnUnlock.setText("")
        self.btnUnlock.setAutoRepeat(False)
        self.btnUnlock.setAutoExclusive(False)
        self.btnUnlock.setObjectName("btnUnlock")

        self.btnUnlock.clicked.connect (self.btnUnlock_click)

        MainWindow.setCentralWidget(self.centralwidget)

        ## Get username database

        self.username = files.readall("/tmp/username.tmp")

        ## Get distro database
        self.cs = files.readall("/proc/info/cs")
        self.cd = files.readall("/proc/info/cd")
        self.ver = files.readall("/proc/info/ver")
        MainWindow.setWindowTitle(self.cs + " " + self.ver + " (" + self.cd + ")")

        ## Get locale database
        self.locale = control.read_record("locale", "/etc/gui")
        if self.locale == None: self.locale = "English"

        ## Locale section

        self.lc_font = control.read_record("font", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_guest = control.read_record("guest", "/usr/share/locales/" + self.locale + "/desktop.locale")


        ## Set name ##
        if self.username=="guest":
            self.name = self.lc_guest
        else:
            first_name = control.read_record("first_name", "/etc/users/" + self.username)
            last_name = control.read_record("last_name", "/etc/users/" + self.username)
            if not first_name == None and not last_name == None:
                self.name = first_name + " " + last_name
            elif not first_name == None:
                self.name = first_name
            elif not last_name == None:
                self.name = last_name
            else:
                self.name = self.username

        ## Set font ##
        font = QFont()
        font.setFamily(self.lc_font)
        MainWindow.setFont(font)

        ## Default bgcolor check ##
        bgcolor = None
        if not self.username == "guest":
            bgcolor = control.read_record("lock.bgcolor", "/etc/users/" + self.username)
        if bgcolor == None:
            bgcolor = control.read_record("lock.bgcolor", "/etc/gui")
        background = None
        if not self.username == "guest":
            background = control.read_record("lock.x19.background", "/etc/users/" + self.username)
        if background == None:
            background = control.read_record("lock.x19.background", "/etc/gui")

        if not bgcolor == None:
            self.btnUnlock.setStyleSheet("background-color: " + bgcolor + ";")
        elif not background==None:
            self.btnUnlock.setStyleSheet("background-image: url(" + files.input(background) + ");")
        else:
            self.btnUnlock.setStyleSheet("background-color: blue;")


        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))


MainWindow = QtWidgets.QMainWindow()
w = Ui_MainWindow()
w.setupUi(MainWindow)
MainWindow.showFullScreen()
