import sys, os, hashlib, getpass
from libnam import files, control, permissions, colors

def uadd (input_username,user):
    if permissions.check_root(user):
        enable_cli = control.read_record("enable_cli", "/etc/guest")
        ## Check exists user ##
        if files.isfile("/etc/users/" + input_username) or input_username == "root":
            colors.show("uadd", "fail", input_username + ": user exists.")
        elif input_username == "guest" and enable_cli == "Yes":
            colors.show("uadd", "fail", "guest user has already enabled")
        else:
            while True:
                new_password = getpass.getpass("Enter a new password: ")
                confirm_password = getpass.getpass("Confirm the new password: ")

                if not new_password == confirm_password:
                    colors.show("uadd", "fail", "confirm the password again.")
                else:
                    break

            hashname = hashlib.sha3_256(str(input_username).encode()).hexdigest()
            hashcode = hashlib.sha3_512(str(new_password).encode()).hexdigest()

            first_name = input("   First name    []: ")
            last_name = input("   Last name     []: ")
            company = input("   Company name  []: ")
            birthday = input("   Birthday      [y/m/d]: ")
            gender = input("   Gender        [Male/Female]: ")
            blood_type = input("   Blood type    [O/A/B/AB]: ")
            phone = input("   Phone number  []: ")
            website = input("   Website       []: ")
            email = input("   Email address []: ")

            correct = input("Is this information correct? [Y/n]: ").upper()

            if correct == "Y":
                files.create("/etc/users/" + input_username)
                if not files.isdir("/desk/" + input_username): files.mkdir("/desk/" + input_username)

                control.write_record("username", hashname, "/etc/users/" + input_username)
                control.write_record("code", hashcode, "/etc/users/" + input_username)

                if not (first_name == None or first_name == ""): control.write_record("first_name", first_name,
                                                                                      "/etc/users/" + input_username)
                if not (last_name == None or last_name == ""): control.write_record("last_name", last_name,
                                                                                    "/etc/users/" + input_username)
                if not (company == None or company == ""): control.write_record("company", company,
                                                                                "/etc/users/" + input_username)
                if not (birthday == None or birthday == ""): control.write_record("birthday", birthday,
                                                                                  "/etc/users/" + input_username)
                if not (gender == None or gender == ""): control.write_record("gender", gender,
                                                                              "/etc/users/" + input_username)
                if not (blood_type == None or blood_type == ""): control.write_record("blood_type", blood_type,
                                                                                      "/etc/users/" + input_username)
                if not (phone == None or phone == ""): control.write_record("phone", phone,
                                                                            "/etc/users/" + input_username)
                if not (website == None or website == ""): control.write_record("website", website,
                                                                                "/etc/users/" + input_username)
                if not (email == None or email == ""): control.write_record("email", email,
                                                                            "/etc/users/" + input_username)

                permissions.create ("/desk/"+input_username,7,1,0,input_username) ## Create permission for another user
    else:
        colors.show ("uadd","perm","")

if not sys.argv == []:
    uadd(sys.argv[0],files.readall ("/proc/info/su"))
else:
    colors.show("uadd", "fail", "no inputs.")