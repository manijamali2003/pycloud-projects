from libnam import process, files, permissions, colors, control
import os, importlib

## Graphical application library ##

## Run app ##
def system (cmd):
    os.system (files.readall ("/proc/info/py")+" vmnam.pyc exec app "+cmd)

## Create id ##
def cid (id):
    if files.isfile ("/proc/id/"+id):
        colors.show("libcloud.app.cid", "fail", id+": id has already exists.")
    else:
        files.create ("/proc/id/"+id)

## Kill id ##
def kid (id):
    if not files.isfile ("/proc/id/"+id):
        colors.show("libcloud.app.kid", "fail", id+": id not found.")
    else:
        files.remove ("/proc/id/"+id)