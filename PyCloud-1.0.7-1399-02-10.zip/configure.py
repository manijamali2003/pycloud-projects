
hostname = input ("Enter a new hostname: ") 
password = input ("Enter a new root password: ")

file = open ("config/hostname.txt","w")
file.write(hostname)
file.close()

file = open ("config/password.txt","w")
file.write(password)
file.close()
