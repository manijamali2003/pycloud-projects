from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files, control, permissions
from libcloud import core
import sys, os
import hashlib, importlib

from PyQt5 import QtCore, QtGui, QtWidgets

class MainApp(QtWidgets.QMainWindow):
    model = control.read_record("model","/etc/gui")
    fontsize = control.read_record("fontsize", "/etc/gui")
    username = ""
    def x19_lock(self):
        from x19 import lock
        importlib.reload(lock)
        w1 = lock.w
    def suspend_act(self):
        import suspendpage
        w1 = suspendpage.w
        importlib.reload(suspendpage) ##https://www.geeksforgeeks.org/reloading-modules-python/
    def lock_act(self):
        files.create("/tmp/username.tmp")
        files.write("/tmp/username.tmp", self.username)
        if self.model == "x19":
            self.x19_lock()
        else:
            exit(0)
    def escape_act(self):
        core.shutdown()
        exit(0)
    def restart_act(self):
        core.reboot()
        exit(0)
    def account_setting_act(self):
        print ("This account setting action")
    def switchuser_act(self):
        core.switch_user()
    def logout_act(self):
        core.logout()
        exit(0)

    def __init__(self):
        super().__init__()

        ## Font Size configure ##
        if self.fontsize==None:
            self.fontsize=12
        else:
            self.fontsize=int(self.fontsize)

        ## Menu bar design
        self.setObjectName("self")
        self.resize(1920, 1080)
        self.centralwidget = QtWidgets.QWidget(self)
        self.centralwidget.setObjectName("centralwidget")
        self.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(self)
        self.menubar.setStyleSheet("background: none;")
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1920, 23))
        self.menubar.setObjectName("menubar")
        self.menuApplications = QtWidgets.QMenu(self.menubar)
        self.menuApplications.setObjectName("menuApplications")

        self.menuEtcetra = QtWidgets.QMenu(self.menubar)
        self.menuEtcetra.setObjectName("menuEtcetra")
        self.menuAccount = QtWidgets.QMenu(self.menuEtcetra)
        self.menuAccount.setObjectName("menuAccount")
        self.menuPower = QtWidgets.QMenu(self.menuEtcetra)
        self.menuPower.setObjectName("menuPower")
        self.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(self)
        self.statusbar.setObjectName("statusbar")
        self.setStatusBar(self.statusbar)
        self.actionAccount_Setting = QtWidgets.QAction(self)
        self.actionAccount_Setting.setObjectName("actionAccount_Setting")
        self.actionSwitch_user = QtWidgets.QAction(self)
        self.actionSwitch_user.setObjectName("actionSwitch_user")
        self.actionLogout = QtWidgets.QAction(self)
        self.actionLogout.setObjectName("actionLogout")
        self.actionEscape = QtWidgets.QAction(self)
        self.actionEscape.setObjectName("actionEscape")
        self.actionSuspend = QtWidgets.QAction(self)
        self.actionSuspend.setObjectName("actionSuspend")
        self.actionRestart = QtWidgets.QAction(self)
        self.actionRestart.setObjectName("actionRestart")

        self.actionLock = QtWidgets.QAction(self)
        self.actionLock.setObjectName("actionLock")

        self.menuAccount.addAction(self.actionAccount_Setting)
        self.menuAccount.addAction(self.actionSwitch_user)
        self.menuAccount.addAction(self.actionLock)
        self.menuAccount.addAction(self.actionLogout)
        self.menuPower.addAction(self.actionEscape)
        self.menuPower.addAction(self.actionSuspend)
        self.menuPower.addAction(self.actionRestart)
        self.menuEtcetra.addAction(self.menuAccount.menuAction())
        self.menuEtcetra.addAction(self.menuPower.menuAction())
        self.menubar.addAction(self.menuApplications.menuAction())
        self.menubar.addAction(self.menuEtcetra.menuAction())

        ## Actions ##
        self.actionRestart.triggered.connect (self.restart_act)
        self.actionAccount_Setting.triggered.connect (self.account_setting_act)
        self.actionLock.triggered.connect(self.lock_act)
        self.actionEscape.triggered.connect(self.escape_act)
        self.actionLogout.triggered.connect(self.logout_act)
        self.actionSuspend.triggered.connect(self.suspend_act)
        self.actionSwitch_user.triggered.connect(self.switchuser_act)

        self.statusbar.setStyleSheet("color: white;")

        ## Get username database
        username = control.read_record("username", "/tmp/su.tmp")
        code = control.read_record("code", "/tmp/su.tmp")

        self.username = username

        ## Remove temporary files
        if files.isfile("/tmp/username.tmp"): files.remove("/tmp/username.tmp")
        if files.isfile("/tmp/su.tmp"): files.remove("/tmp/su.tmp")

        ## Switch this selected user
        files.write("/proc/info/su", username)
        permissions.user = username

        ## Create pwd for this user
        if username == "root":
            files.write("/proc/info/pwd", "/root")
        else:
            files.write("/proc/info/pwd", "/desk/" + username)


        ## Get distro database
        self.cs = files.readall("/proc/info/cs")
        self.cd = files.readall("/proc/info/cd")
        self.ver = files.readall("/proc/info/ver")
        self.setWindowTitle(self.cs + " " + self.ver + " (" + self.cd + ")")

        ## Get locale database
        self.locale = control.read_record("locale", "/etc/gui")
        if self.locale == None: self.locale = "English"

        ## locale section ##
        self.lc_escape_action = control.read_record("btnEscape", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_apps = control.read_record("apps", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_etcetra = control.read_record("etcetra", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_guest = control.read_record("guest", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_switchuser_action = control.read_record("switchuser_action",
                                                   "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_logout_action = control.read_record("logout_action", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_power_menu = control.read_record("power_menu", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_restart_action = control.read_record("restart_action", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_locale = control.read_record("locale", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_font = control.read_record("font", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_menubar_direction = control.read_record("menubar_direction",
                                                   "/usr/share/locales/" + self.locale + "/desktop.locale")

        self.lc_lock = control.read_record("lock_action",
                                                   "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_account_setting = control.read_record("account_setting_action",
                                           "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_suspend = control.read_record("suspend_action",
                                           "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_statusbar_lock = control.read_record("statusbar_lock", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_statusbar_switchuser = control.read_record("statusbar_switchuser", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_statusbar_logout = control.read_record("statusbar_logout", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_statusbar_account_setting = control.read_record("statusbar_account_setting", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_statusbar_restart = control.read_record("statusbar_restart", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_statusbar_escape = control.read_record("statusbar_escape", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_statusbar_suspend = control.read_record("statusbar_suspend", "/usr/share/locales/" + self.locale + "/desktop.locale")

        ## Set layout direction'''

        if self.lc_menubar_direction=="rtl":

            self.menubar.setLayoutDirection(QtCore.Qt.RightToLeft)
        else:
            self.menubar.setLayoutDirection(QtCore.Qt.LeftToRight)

        ## Applications ##
        applist = files.list("/usr/share/applications")
        for i in applist:
            self.appAction = self.menuApplications.addAction(i)
            self.appAction.setObjectName(i)

            self.appAction.triggered.connect (self.AppRunner)
            self.shortcut = control.read_record("shortcut","/usr/share/applications/"+i)
            self.comment = control.read_record("comment["+self.locale+"]", "/usr/share/applications/" + i)
            self.name_ = control.read_record("name[" + self.locale + "]", "/usr/share/applications/" + i)
            self.icon = control.read_record("icon","/usr/share/applications/"+i)


            ## Set Icon ##
            title_icon = control.read_record("app.icon", "/usr/share/applications/" + i)
            if title_icon == None:
                title_icon = control.read_record("app.icon", "/etc/gui")
                if not title_icon == None:
                    self.appAction.setIcon(QtGui.QIcon(files.input(title_icon)))
            else:
                self.appAction.setIcon(QtGui.QIcon(files.input(title_icon)))

            if not self.shortcut==None:
                self.appAction.setShortcut(self.shortcut)
            if not self.comment==None:
                self.appAction.setStatusTip(self.comment)
            if not self.name_==None:
                self.appAction.setText(self.name_)
            if not self.icon == None:
                self.appAction.setIcon(QtGui.QIcon(files.input(self.icon)))


        ## Status Tips ##
        self.actionRestart.setStatusTip(self.lc_statusbar_restart)
        self.actionAccount_Setting.setStatusTip(self.lc_statusbar_account_setting)
        self.actionLock.setStatusTip(self.lc_statusbar_lock)
        self.actionEscape.setStatusTip(self.lc_statusbar_escape)
        self.actionLogout.setStatusTip(self.lc_statusbar_logout)
        self.actionSuspend.setStatusTip(self.lc_statusbar_suspend)
        self.actionSwitch_user.setStatusTip(self.lc_statusbar_switchuser)

        ## Hide statusbar or menubar or etc
        statusbar_hide = control.read_record("desktop.statusbar.hide","/etc/gui")
        menubar_hide = control.read_record("desktop.menubar.hide", "/etc/gui")

        if statusbar_hide=="No":
            self.statusbar.setVisible(True)
        else:
            self.statusbar.setVisible(False)

        if menubar_hide=="No":
            self.menubar.setVisible(True)
        else:
            self.menubar.setVisible(False)

        ## Set name ##
        if username=="guest":
            self.name = self.lc_guest
        else:
            first_name = control.read_record("first_name", "/etc/users/" + username)
            last_name = control.read_record("last_name", "/etc/users/" + username)
            if not first_name == None and not last_name == None:
                self.name = first_name + " " + last_name
            elif not first_name == None:
                self.name = first_name
            elif not last_name == None:
                self.name = last_name
            else:
                self.name = username

        ## Set font ##
        #https://stackoverflow.com/questions/32724169/how-to-change-font-size-of-child-qlabel-widget-from-the-groupbox
        self.menubar.setFont(QtGui.QFont(self.lc_font,self.fontsize))
        self.statusbar.setFont(QFont(self.lc_font,self.fontsize))

        self.menuApplications.setFont(QFont(self.lc_font,self.fontsize))
        self.menuEtcetra.setFont(QFont(self.lc_font,self.fontsize))
        self.menuAccount.setFont(QFont(self.lc_font,self.fontsize))
        self.menuPower.setFont(QFont(self.lc_font,self.fontsize))
        self.actionAccount_Setting.setFont(QFont(self.lc_font,self.fontsize))
        self.actionSwitch_user.setFont(QFont(self.lc_font,self.fontsize))
        self.actionLogout.setFont(QFont(self.lc_font,self.fontsize))
        self.actionEscape.setFont(QFont(self.lc_font,self.fontsize))
        self.actionSuspend.setFont(QFont(self.lc_font,self.fontsize))
        self.actionRestart.setFont(QFont(self.lc_font,self.fontsize))
        self.actionLock.setFont(QFont(self.lc_font,self.fontsize))

        ## Check user ##
        if not username == "guest":
            if not files.isfile("/etc/users/" + username):
                exit(0)

            user = control.read_record("username", "/etc/users/" + username)
            hashname = hashlib.sha3_256(
                str(username).encode()).hexdigest()

            if not user == hashname:
                exit(0)

            password = control.read_record("code", "/etc/users/" + username)
            hashcode = hashlib.sha3_512(
                str(code).encode()).hexdigest()

            if not password == hashcode:
                exit(0)
        else:
            enable_gui = control.read_record("enable_gui", "/etc/guest")
            if enable_gui == "No": exit(0)

        ## Desktop /desk files extract ##

        deskdirs = control.read_list("/etc/deskdirs")

        if username == "root":
            for i in deskdirs:
                if not files.isdir("/root/" + i): files.mkdir("/root/" + i)
        else:
            if not files.isdir("/desk/" + username): files.mkdir("/desk/" + username)
            for i in deskdirs:
                if not files.isdir("/desk/" + username + "/" + i): files.mkdir("/desk/" + username + "/" + i)

        ## Default bgcolor check ##
        bgcolor = None
        if not username == "guest":
            bgcolor = control.read_record("desktop.bgcolor", "/etc/users/" + username)
        if bgcolor == None:
            bgcolor = control.read_record("desktop.bgcolor", "/etc/gui")
        background = None
        if not username == "guest":
            background = control.read_record("desktop.x19.background", "/etc/users/" + username)
        if background == None:
            background = control.read_record("desktop.x19.background", "/etc/gui")

        if not bgcolor == None:
            self.setStyleSheet("background-color: " + bgcolor + ";")
        elif not background==None:
            self.setStyleSheet("background-image: url(" + files.input(background) + ");")
        else:
            self.setStyleSheet("background-color: blue;")

        self.menuApplications.setTitle(self.lc_apps)
        self.menuEtcetra.setTitle(self.lc_etcetra)
        self.menuAccount.setTitle(self.name)
        self.menuPower.setTitle(self.lc_power_menu)
        self.actionAccount_Setting.setText(self.lc_account_setting)
        self.actionSwitch_user.setText(self.lc_switchuser_action)
        self.actionLogout.setText(self.lc_logout_action)
        self.actionEscape.setText(self.lc_escape_action)
        self.actionSuspend.setText(self.lc_suspend)
        self.actionRestart.setText(self.lc_restart_action)
        self.actionLock.setText(self.lc_lock)

        QtCore.QMetaObject.connectSlotsByName(self)

    def AppRunner (self):

        sender = self.sender().objectName()
        exec = control.read_record("exec","/usr/share/applications/"+sender)
        app = control.read_record("app","/usr/share/applications/"+sender)
        if not app==None:
            core.app (app)
        elif not exec==None:
            core.system (exec)

w = MainApp()
w.showFullScreen()
