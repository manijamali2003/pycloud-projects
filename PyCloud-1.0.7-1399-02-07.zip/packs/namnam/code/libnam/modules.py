import sys, importlib, imp
from importlib import reload
from libnam import files, colors

## Get modules from /etc/modules ##
def get_modules():
    file = open("etc/modules")
    strv = file.read()
    file.close()
    strv = strv.split("\n")
    for i in strv:
        sys.path.append("./"+i)

## Run module from PyCloud ##
def run_module (module_name):
    if module_name.startswith ("./") and module_name.__contains__("/"):
        # Check program exits ##
        if not (files.isfile (module_name.replace("./","")+".py") or files.isfile (module_name.replace("./","")+".pyc") or files.isfile (module_name.replace("./","")+".pyz")):
            colors.show (module_name,"fail","program not found.")
        else:
            importlib.import_module(files.input(module_name.replace("./","")).replace(".//","").replace("/","."))
    else:
        try:
            imp.find_module(module_name)
            found = True
        except ImportError:
            found = False

        if found==True:
            importlib.import_module(module_name)
        else:
            colors.show(module_name, "fail", "command not found.")


def import_module (module_name):
    if module_name.startswith ("./") and module_name.__contains__("/"):
        # Check program exits ##
        if not (files.isfile (module_name.replace("./","")+".py") or files.isfile (module_name.replace("./","")+".pyc") or files.isfile (module_name.replace("./","")+".pyz")):
            return None
        else:
            return importlib.import_module(files.input(module_name.replace("./","")).replace(".//","").replace("/","."))
    else:
        try:
            imp.find_module(module_name)
            found = True
        except ImportError:
            found = False

        if found == True:
            return importlib.import_module(module_name)
        else:
            return None