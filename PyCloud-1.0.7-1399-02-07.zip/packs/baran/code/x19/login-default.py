from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files, control, process
import importlib, hashlib

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    fontsize = control.read_record("fontsize", "/etc/gui")
    def EscapeClick(self):
        process.endall()
        exit(0)

    def x19_enter(self):
        MainWindow.close()
        from x19 import enter
        w1 = enter.w

    def x19_desktop(self):
        MainWindow.close()
        from x19 import desktop
        w1 = desktop.w

    def check_user(self):
        self.username = self.leUsername.text().lower()
        self.enable_gui = control.read_record("enable_gui", "/etc/guest")
        if self.username == "guest" and self.enable_gui == "Yes":
            self.btnNext.setText(self.lc_btnLogin)
            files.write("/tmp/username.tmp", self.username)
            files.create("/tmp/su.tmp")
            control.write_record("username", self.username, "/tmp/su.tmp")
            control.write_record("code", "", "/tmp/su.tmp")
            if self.model == "x19":
                self.btnNext.clicked.connect(self.x19_desktop)
            else:
                exit(0)
        elif files.isfile("/etc/users/" + self.username):
            self.hashname = hashlib.sha3_256(
                str(self.username).encode()).hexdigest()
            self.user = control.read_record("username", "/etc/users/" + self.username)
            if self.user == self.hashname:
                files.write("/tmp/username.tmp", self.username)
                if self.model == "x19":
                    self.btnNext.clicked.connect(self.x19_enter)
                else:
                    exit(0)
            else:
                self.btnNext.setStyleSheet(
                    "background-color: red;color: white;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: orange;")
                self.lblUserNotFound.setText(self.lc_lblUserNotFound.replace("{0}", self.username))
                QTimer.singleShot(3000, self.clear)
        else:
            self.btnNext.setStyleSheet(
                "background-color: red;color: white;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: orange;")
            self.lblUserNotFound.setText(self.lc_lblUserNotFound.replace("{0}", self.username))
            QTimer.singleShot(3000, self.clear)

    def clear(self):
        self.btnNext.setStyleSheet(
            "background-color: blue;color: white;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: blue;")
        self.lblUserNotFound.clear()
        self.leUsername.clear()

    def setupUi(self, MainWindow):
        ## Font Size configure ##
        if self.fontsize == None:
            self.fontsize = 12
        else:
            self.fontsize = int(self.fontsize)
        ## Menu bar design
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1920, 1080)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        MainWindow.setCentralWidget(self.centralwidget)

        cs = files.readall("/proc/info/cs")
        cd = files.readall("/proc/info/cd")
        ver = files.readall("/proc/info/ver")
        MainWindow.setWindowTitle(cs + " " + ver + " (" + cd + ")")
        MainWindow.setWindowFlags(Qt.FramelessWindowHint)
        MainWindow.resize(1920, 1080)

        self.bgcolor = control.read_record("login.bgcolor", "/etc/gui")
        self.background = control.read_record("login.x19.background", "/etc/gui")
        self.model = control.read_record("model", "/etc/gui")

        self.locale = control.read_record("locale", "/etc/gui")
        if self.locale == None: self.locale = "English"

        ## locale section ##
        self.lc_btnLogin = control.read_record("btnLogin", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_lblUserNotFound = control.read_record("lblUserNotFound", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_lblUsername = control.read_record("lblUsername", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_btnEscape = control.read_record("btnEscape", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_btnNext = control.read_record("btnNext", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_font = control.read_record("font", "/usr/share/locales/" + self.locale + "/desktop.locale")
        ##

        if not self.bgcolor == None:
            MainWindow.setStyleSheet("background-color: " + self.bgcolor + ";")
        else:
            MainWindow.setStyleSheet("background-color: purple;")

        self.verticalLayoutWidget = QWidget(MainWindow)
        self.verticalLayoutWidget.setGeometry(QRect(770, 460, 361, 106))  # 360
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.lblUsername = QLabel(self.verticalLayoutWidget)
        self.lblUsername.setObjectName("label")
        self.lblUsername.setText(self.lc_lblUsername)
        self.lblUsername.setStyleSheet("color: white;")
        self.lblUsername.setFont(QFont(self.lc_font,self.fontsize))
        self.verticalLayout.addWidget(self.lblUsername)
        self.leUsername = QLineEdit(self.verticalLayoutWidget)
        self.leUsername.setObjectName("lineEdit")
        self.leUsername.setFont(QFont(self.lc_font, self.fontsize))
        self.leUsername.setStyleSheet(
            "background-color: white;border-radius: 15% 15%;color: black;border-style: solid;border-width: 1%;border-color: white;")
        self.leUsername.setMinimumHeight(30)
        self.verticalLayout.addWidget(self.leUsername)

        self.hlayout = QHBoxLayout()

        self.btnEscape = QPushButton(self.verticalLayoutWidget)
        self.btnEscape.setObjectName("pushButton")
        self.btnEscape.setFont(QFont(self.lc_font, self.fontsize))
        self.btnEscape.setStyleSheet(
            "background-color: pink;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: pink;")
        self.btnEscape.clicked.connect(self.EscapeClick)
        self.btnEscape.setMinimumHeight(30)
        self.btnEscape.setText(self.lc_btnEscape)

        self.btnNext = QPushButton(self.verticalLayoutWidget)
        self.btnNext.setObjectName("pushButton")
        self.btnNext.setFont(QFont(self.lc_font, self.fontsize))
        self.btnNext.setStyleSheet(
            "background-color: blue;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: blue;")
        self.btnNext.clicked.connect(self.check_user)
        self.btnNext.setMinimumHeight(30)
        self.btnNext.setText(self.lc_btnNext)

        self.hlayout.addWidget(self.btnEscape)
        self.hlayout.addWidget(self.btnNext)
        self.verticalLayout.addLayout(self.hlayout)

        self.lblUserNotFound = QLabel(self.verticalLayoutWidget)
        self.lblUserNotFound.setFont(QFont(self.lc_font, self.fontsize))
        self.lblUserNotFound.setStyleSheet("color: white;")

        self.verticalLayout.addWidget(self.lblUserNotFound)

        ## Get userlogo from data base ##
        self.userlogo = control.read_record("login.x19.userlogo", "/etc/gui")
        if self.userlogo == None:
            self.userlogo = ""
        self.btnAccountImage = QPushButton(MainWindow)
        self.btnAccountImage.setGeometry(QRect(770, 83, 361, 361))
        self.btnAccountImage.setStyleSheet("background-color: white;background-image: url(" + files.input(
            self.userlogo) + ");color: white;border-radius: 180% 180%;border-style: solid;border-width: 1%;border-color: blue;")


    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))

MainWindow = QtWidgets.QMainWindow()
w = Ui_MainWindow()
w.setupUi(MainWindow)
MainWindow.showFullScreen()
