from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files, control, permissions, process
from libcloud import core
import hashlib, importlib

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    fontsize = control.read_record("fontsize", "/etc/gui")
    next_bgcolor = control.read_record("login.next.bgcolor", "/etc/gui")
    next_fgcolor = control.read_record("login.next.fgcolor", "/etc/gui")
    escape_bgcolor = control.read_record("login.escape.bgcolor", "/etc/gui")
    escape_fgcolor = control.read_record("login.escape.fgcolor", "/etc/gui")
    def check_password(self):
        self.password = self.lePassword.text()

        self.hashcode = hashlib.sha3_512(
            str(self.password).encode()).hexdigest()

        self.code = control.read_record("code", "/etc/users/" + self.username)

        if self.hashcode == self.code:
            MainWindow.close()
        else:
            self.btnLogin.setStyleSheet(
                "background-color: red;color: white;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: orange;")
            self.lblWrongpassword.setText(self.lc_lblWrongpassword)
            QTimer.singleShot(3000, self.clear)

    def clear(self):
        self.btnLogin.setStyleSheet(
            "background-color: blue;color: white;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: blue;")
        self.lePassword.clear()
        self.lblWrongpassword.clear()
    def setupUi(self, MainWindow):
        ## Font Size configure ##
        if self.fontsize == None:
            self.fontsize = 12
        else:
            self.fontsize = int(self.fontsize)
        ## Menu bar design
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1920, 1080)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        MainWindow.setCentralWidget(self.centralwidget)

        ## Get username database

        self.username = files.readall("/tmp/username.tmp")

        ## Get distro database
        self.cs = files.readall("/proc/info/cs")
        self.cd = files.readall("/proc/info/cd")
        self.ver = files.readall("/proc/info/ver")

        MainWindow.setWindowTitle(self.cs + " " + self.ver + " (" + self.cd + ")")

        ## Get locale database
        self.locale = control.read_record("locale", "/etc/gui")
        if self.locale == None: self.locale = "English"

        ## Locale section

        self.lc_font = control.read_record("font", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_guest = control.read_record("guest", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_btnUnlock = control.read_record("btnUnlock", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_btnEscape = control.read_record("btnEscape", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_lblWrongpassword = control.read_record("lblWrongpassword",
                                                       "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_lblPassword = control.read_record("lblPassword",
                                                  "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_font = control.read_record("font", "/usr/share/locales/" + self.locale + "/desktop.locale")

        ## Set name ##
        if self.username=="guest":
            self.name = self.lc_guest
        else:
            first_name = control.read_record("first_name", "/etc/users/" + self.username)
            last_name = control.read_record("last_name", "/etc/users/" + self.username)
            if not first_name == None and not last_name == None:
                self.name = first_name + " " + last_name
            elif not first_name == None:
                self.name = first_name
            elif not last_name == None:
                self.name = last_name
            else:
                self.name = self.username

        ## Default bgcolor check ##
        bgcolor = None
        if not self.username == "guest":
            bgcolor = control.read_record("lock.bgcolor", "/etc/users/" + self.username)
        if bgcolor == None:
            bgcolor = control.read_record("lock.bgcolor", "/etc/gui")

        if bgcolor == None:
            MainWindow.setStyleSheet("background-color:  purple;")
        else:
            MainWindow.setStyleSheet("background-color: " + bgcolor + ";")

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.username = files.readall("/tmp/username.tmp")

        self.verticalLayoutWidget = QWidget(MainWindow)
        self.verticalLayoutWidget.setGeometry(QRect(770, 460, 361, 106))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.first_name = control.read_record("first_name", "/etc/users/" + self.username)
        self.last_name = control.read_record("last_name", "/etc/users/" + self.username)
        if not self.first_name == None and not self.last_name == None:
            self.name = self.first_name + " " + self.last_name
        elif not self.first_name == None:
            self.name = self.first_name
        elif not self.last_name == None:
            self.name = self.last_name
        else:
            self.name = self.username

        self.lblPassword = QLabel(self.verticalLayoutWidget)
        self.lblPassword.setFont(QFont(self.lc_font, self.fontsize))
        self.lblPassword.setObjectName("label")
        self.lblPassword.setText(self.lc_lblPassword.replace("{0}", self.name))
        self.lblPassword.setStyleSheet("color: white;")
        self.verticalLayout.addWidget(self.lblPassword)
        self.lePassword = QLineEdit(self.verticalLayoutWidget)
        self.lePassword.setObjectName("lineEdit")
        self.lePassword.setFont(QFont(self.lc_font, self.fontsize))
        self.lePassword.setStyleSheet(
            "background-color: white;border-radius: 15% 15%;color: black;border-style: solid;border-width: 1%;border-color: white;")
        self.lePassword.setMinimumHeight(30)
        self.lePassword.setEchoMode(QLineEdit.Password)
        self.verticalLayout.addWidget(self.lePassword)

        self.hlayout = QHBoxLayout()

        self.btnLogin = QPushButton(self.verticalLayoutWidget)
        self.btnLogin.setFont(QFont(self.lc_font, self.fontsize))
        self.btnLogin.setObjectName("pushButton")
        self.btnLogin.setText(self.lc_btnUnlock)
        self.btnLogin.setStyleSheet(
            "background-color: blue;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: blue;")
        self.btnLogin.clicked.connect(self.check_password)
        self.btnLogin.setMinimumHeight(30)

        self.hlayout.addWidget(self.btnLogin)

        self.verticalLayout.addLayout(self.hlayout)

        self.lblWrongpassword = QLabel(self.verticalLayoutWidget)
        self.lblWrongpassword.setStyleSheet("color: white;")
        self.lblWrongpassword.setFont(QFont(self.lc_font, self.fontsize))

        self.verticalLayout.addWidget(self.lblWrongpassword)

        ## Get userlogo from data base ##
        self.userlogo = control.read_record("login.x19.userlogo", "/etc/users/" + self.username)
        if self.userlogo == None:
            self.userlogo = control.read_record("login.x19.userlogo", "/etc/gui")
            if self.userlogo == None:
                self.userlogo = ""

        self.btnAccountImage = QPushButton(MainWindow)
        self.btnAccountImage.setGeometry(QRect(770, 83, 361, 361))
        self.btnAccountImage.setStyleSheet("background-color: white;background-image: url(" + files.input(self.userlogo) + ");color: white;border-radius: 180% 180%;border-style: solid;border-width: 1%;border-color: none;")

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))


MainWindow = QtWidgets.QMainWindow()
w = Ui_MainWindow()
w.setupUi(MainWindow)
MainWindow.showFullScreen()
