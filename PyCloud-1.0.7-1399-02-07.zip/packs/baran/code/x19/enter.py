from PyQt5.QtWidgets import *
from PyQt5 import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from libnam import files, control, process
import importlib, hashlib

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    fontsize = control.read_record("fontsize", "/etc/gui")
    def EscapeClick(self):
        process.endall()
        exit(0)

    def x19_desktop(self):
        MainWindow.close()
        from x19 import desktop
        w1 = desktop.w

    def check_password(self):
        self.password = self.lePassword.text()

        self.hashcode = hashlib.sha3_512(
            str(self.password).encode()).hexdigest()

        self.code = control.read_record("code", "/etc/users/" + self.username)

        if self.hashcode == self.code:
            files.create("/tmp/su.tmp")
            control.write_record("username", self.username.lower(), "/tmp/su.tmp")
            control.write_record("code", self.lePassword.text(), "/tmp/su.tmp")

            if self.model == "x19":
                files.write("/proc/info/su", self.username)
                self.btnLogin.clicked.connect(self.x19_desktop)
            else:
                exit(0)
        else:
            self.btnLogin.setStyleSheet(
                "background-color: red;color: white;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: orange;")
            self.lblWrongpassword.setText(self.lc_lblWrongpassword)
            QTimer.singleShot(3000, self.clear)

    def clear(self):
        self.btnLogin.setStyleSheet(
            "background-color: blue;color: white;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: blue;")
        self.lePassword.clear()
        self.lblWrongpassword.clear()
    def setupUi(self, MainWindow):
        ## Font Size configure ##
        if self.fontsize == None:
            self.fontsize = 12
        else:
            self.fontsize = int(self.fontsize)
        ## Menu bar design
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1920, 1080)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        MainWindow.setCentralWidget(self.centralwidget)

        cs = files.readall("/proc/info/cs")
        cd = files.readall("/proc/info/cd")
        ver = files.readall("/proc/info/ver")
        MainWindow.setWindowTitle(cs + " " + ver + " (" + cd + ")")
        MainWindow.setWindowFlags(Qt.FramelessWindowHint)
        MainWindow.resize(1920, 1080)

        self.bgcolor = control.read_record("login.bgcolor", "/etc/gui")
        self.background = control.read_record("login.x19.background", "/etc/gui")
        self.model = control.read_record("model", "/etc/gui")

        self.locale = control.read_record("locale", "/etc/gui")
        if self.locale == None: self.locale = "English"

        self.lc_btnLogin = control.read_record("btnLogin", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_btnEscape = control.read_record("btnEscape", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_lblWrongpassword = control.read_record("lblWrongpassword",
                                                  "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_lblPassword = control.read_record("lblPassword", "/usr/share/locales/" + self.locale + "/desktop.locale")
        self.lc_font = control.read_record("font", "/usr/share/locales/" + self.locale + "/desktop.locale")

        if not self.bgcolor == None:
            MainWindow.setStyleSheet("background-color: " + self.bgcolor + ";")
        else:
            MainWindow.setStyleSheet("background-color: purple;")

        self.username = files.readall("/tmp/username.tmp")

        self.verticalLayoutWidget = QWidget(MainWindow)
        self.verticalLayoutWidget.setGeometry(QRect(770, 460, 361, 106))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.first_name = control.read_record("first_name", "/etc/users/" + self.username)
        self.last_name = control.read_record("last_name", "/etc/users/" + self.username)
        if not self.first_name == None and not self.last_name == None:
            self.name = self.first_name + " " + self.last_name
        elif not self.first_name == None:
            self.name = self.first_name
        elif not self.last_name == None:
            self.name = self.last_name
        else:
            self.name = self.username

        self.lblPassword = QLabel(self.verticalLayoutWidget)
        self.lblPassword.setObjectName("label")
        self.lblPassword.setFont(QFont(self.lc_font, self.fontsize))
        self.lblPassword.setText(self.lc_lblPassword.replace("{0}", self.name))
        self.lblPassword.setStyleSheet("color: white;")
        self.verticalLayout.addWidget(self.lblPassword)
        self.lePassword = QLineEdit(self.verticalLayoutWidget)
        self.lePassword.setObjectName("lineEdit")
        self.lePassword.setFont(QFont(self.lc_font, self.fontsize))
        self.lePassword.setStyleSheet(

            "background-color: white;border-radius: 15% 15%;color: black;border-style: solid;border-width: 1%;border-color: white;")
        self.lePassword.setMinimumHeight(30)
        self.lePassword.setEchoMode(QLineEdit.Password)
        self.verticalLayout.addWidget(self.lePassword)

        self.hlayout = QHBoxLayout()

        self.btnEscape = QPushButton(self.verticalLayoutWidget)
        self.btnEscape.setObjectName("pushButton")
        self.btnEscape.setFont(QFont(self.lc_font, self.fontsize))
        self.btnEscape.clicked.connect(self.EscapeClick)
        self.btnEscape.setStyleSheet(
            "background-color: pink;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: pink;")
        self.btnEscape.setText(self.lc_btnEscape)
        self.btnEscape.setMinimumHeight(30)

        self.btnLogin = QPushButton(self.verticalLayoutWidget)
        self.btnLogin.setObjectName("pushButton")
        self.btnLogin.setText(self.lc_btnLogin)
        self.btnLogin.setFont(QFont(self.lc_font, self.fontsize))
        self.btnLogin.setStyleSheet(
            "background-color: blue;border-radius: 15% 15%;color: white;border-style: solid;border-width: 1%;border-color: blue;")
        self.btnLogin.clicked.connect(self.check_password)
        self.btnLogin.setMinimumHeight(30)

        self.hlayout.addWidget(self.btnEscape)
        self.hlayout.addWidget(self.btnLogin)

        self.verticalLayout.addLayout(self.hlayout)

        self.lblWrongpassword = QLabel(self.verticalLayoutWidget)
        self.lblWrongpassword.setFont(QFont(self.lc_font, self.fontsize))
        self.lblWrongpassword.setStyleSheet("color: white;")

        self.verticalLayout.addWidget(self.lblWrongpassword)

        ## Get userlogo from data base ##
        self.userlogo = control.read_record("login.x19.userlogo", "/etc/users/" + self.username)
        if self.userlogo == None:
            self.userlogo = control.read_record("login.x19.userlogo", "/etc/gui")
            if self.userlogo == None:
                self.userlogo = ""

        self.btnAccountImage = QPushButton(MainWindow)
        self.btnAccountImage.setGeometry(QRect(770, 83, 361, 361))
        self.btnAccountImage.setStyleSheet("background-color: white;background-image: url(" + files.input(
            self.userlogo) + ");color: white;border-radius: 180% 180%;border-style: solid;border-width: 1%;border-color: none;")

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))


MainWindow = QtWidgets.QMainWindow()
w = Ui_MainWindow()
w.setupUi(MainWindow)
MainWindow.showFullScreen()