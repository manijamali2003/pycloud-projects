from libcloud import widget, core
from PyQt5 import QtWidgets, QtCore

class MainApp (widget.MainApp):
    ## New ##
    def new_act(self):
        self.SetWindowTitle("Untitled - Barge")
        self.txtBox.clear()

    ## New Barge Action ##
    def new_barge_act (self):
        core.system("barge")

    ## Font dialog ##
    def font_act (self):
        f = QtWidgets.QFontDialog()
        self.Layout.addWidget(f)
        self.txtBox.setFont(f.font())

    ## Color dialog ##
    def bgcolor_act(self):
        self.Layout.addWidget(QtWidgets.QColorDialog())

        ## Color dialog ##
    def fgcolor_act(self):
        self.Layout.addWidget(QtWidgets.QColorDialog())

    def __init__(self):
        super().__init__()
        self.SetWindowTitle ("Untitled - Barge")

        menubar = QtWidgets.QMenuBar()
        self.file = menubar.addMenu("File")
        self.file_new = self.file.addAction("New")
        self.file_new_barge = self.file.addAction("New Barge")
        self.file_open = self.file.addAction("Open")
        self.file_save = self.file.addAction("Save")
        self.file_save_as = self.file.addAction("Save As")
        self.file_exit = self.file.addAction("Exit")

        self.view = menubar.addMenu("View")
        self.view_themes = self.view.addMenu("Themes")
        self.view_bgcolor = self.view.addAction("BackColor")
        self.view_fgcolor = self.view.addAction("ForeColor")
        self.view_font = self.view.addAction("Font")
        self.view_reset = self.view.addAction("Reset")

        self.help = menubar.addMenu("Help")
        self.help_about = self.help.addAction("About")

        ## Actions ##
        self.file_new.triggered.connect (self.new_act)
        self.file_new_barge.triggered.connect(self.new_barge_act)
        self.file_exit.triggered.connect(self.close)
        self.view_bgcolor.triggered.connect(self.bgcolor_act)
        self.view_fgcolor.triggered.connect(self.fgcolor_act)
        self.view_font.triggered.connect(self.font_act)

        ## TextBox ##
        self.txtBox = widget.TextBox()
        self.txtBox.SetFontFamily ("Chilanka")
        self.txtBox.SetFontSize (30)
        self.Layout.addWidget(menubar)
        self.Layout.addWidget(self.txtBox)

app = QtWidgets.QApplication([])
w = MainApp()
w.show()
app.exec_()