import sys
from libnam import files

def help(helpfile):
    if helpfile=="":
        print (files.readall("/usr/share/helps/cmdall.txt"))
    else:
        if files.isfile ("/usr/share/helps/commands/"+helpfile+".txt"):
            print (files.readall("/usr/share/helps/commands/"+helpfile+".txt"))
        else:
            print(files.readall("/usr/share/helps/cmdall.txt"))

if sys.argv==[]:
    help("")
else:
    help(sys.argv[0])

