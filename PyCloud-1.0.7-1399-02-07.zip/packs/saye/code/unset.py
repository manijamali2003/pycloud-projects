import sys, os, hashlib
from libnam import files, control, permissions, colors, process

def unset (name):
    select = files.readall("/proc/info/sel")
    if not select.startswith ("/proc/"):
        if permissions.check(files.output(select),"w",files.readall("/proc/info/su")):
            control.remove_record (name,select)
        else:
            colors.show ("unset","perm","")
    else:
        control.remove_record (name,select)

for i in sys.argv:
    unset (i)