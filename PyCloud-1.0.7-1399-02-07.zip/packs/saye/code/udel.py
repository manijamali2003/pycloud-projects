import sys, os, hashlib
from libnam import files, control, permissions, colors

def udel (input_username,user):
    ## Check not exists user account ##
    if input_username==user:
        colors.show ("udel","fail",input_username+": cannot remove switched user.")
    else:
        if permissions.check_root(user):
            if not files.isfile("/etc/users/" + input_username):
                colors.show("udel", "fail", input_username + ": user not found.")
            else:
                if input_username == "root":
                    colors.show("udel", "fail", input_username + ": is a permanet user.")
                else:
                    hashname = hashlib.sha3_256(str(input_username).encode()).hexdigest()  ## Create hashname
                    username = control.read_record("username", "/etc/users/" + input_username)

                    if not hashname == username:
                        colors.show("udel", "fail", input_username + ": user not found.")
                    else:
                        files.remove("/etc/users/" + input_username)

                        keep = input(
                            "Do you like to keep user directory \'/desk/" + input_username + "\' after removing this user? [Y/n]: ").upper()

                        if not keep == "Y":
                            if files.isdir("/desk/" + input_username):
                                files.removedirs("/desk/" + input_username)
        else:
            colors.show ("udel","perm","")

if not sys.argv == []:
    udel(sys.argv[0],files.readall ("/proc/info/su"))
else:
    colors.show("udel", "fail", "no inputs.")