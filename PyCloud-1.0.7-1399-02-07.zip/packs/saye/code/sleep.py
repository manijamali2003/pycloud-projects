import sys, os, time

if sys.argv==[]:
    time.sleep(3)
else:
    timeout = float(sys.argv[0])
    time.sleep(int(timeout))