from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import importlib
from libnam import control, files

## Colors ##

class Color:
    # https://www.rapidtables.com/web/color/html-color-codes.html #
    ## Red Colors ##
    LightSalmon = "#FFA07A"
    Salmon = "#FA8072"
    DarkSalmon = "#E9967A"
    LightCoral = "#F08080"
    IndianRed = "#CD5C5C"
    Crimson = "#DC143C"
    FireBrick = "#B22222"
    Red = "#FF0000"
    DarkRed = "#8B0000"

    ## Orange colors ##
    Coral = "#FF7F50"
    Tomato = "#FF6347"
    OrangeRed = "#FF4500"
    Gold = "#FFD700"
    Orange = "#FFA500"
    DarkOrange = "#FF8C00"

    ## Yellow colors ##
    LightYellow = "#FFFFE0"
    LemonChiffon = "#FFFACD"
    LightGoldenrodYellow = "#FAFAD2"
    Papayawhip = "#FFEFD5"
    Moccasin = "#FFE4B5"
    PeachPuff = "#FFDAB9"
    PaleGoldenrod = "#EEE8AA"
    Khaki = "#F0E68C"
    DarkKhaki = "#BDB76B"
    Yellow = "#FFFF00"

    ## Green colors ##
    LawnGreen = "#7CFC00"
    Chartreuse = "#7FFF00"
    LimeGreen = "#32CD32"
    Lime = "#00FF00"
    ForestGreen = "#228B22"
    Green = "#008000"
    DarkGreen = "#006400"
    GreenYellow = "#ADFF2F"
    YellowGreen = "#9ACD32"
    SpringGreen = "#00FF7F"
    MediumSpringGreen = "#00FA9A"
    LightGreen = "#90EE90"
    PaleGreen = "#98FB98"
    DarkSeaGreen = "#8FBC8F"
    MediumSeaGreen = "#3CB371"
    SeaGreen = "#2E8B57"
    Olive = "#808000"
    DarkOliveGreen = "#556B2F"
    OliveDrab = "#6B8E23"

    ## Cyan Colors ##
    LightCyan = "#E0FFFF"
    Cyan = "#00FFFF"
    Aqua = "#00FFFF"
    AquaMarine = "#7FFFD4"
    MediumAquaMarine = "#66CDAA"
    PaleTurquoise = "#AFEEEE"
    Turquoise = "#40E0D0"
    MediumTurquoise = "#48D1CC"
    DarkTurquoise = "#00CED1"
    LightSeaGreen = "#20B2AA"
    CadetBlue = "#5F9EA0"
    DarkCyan = "#008B8B"
    Teal = "#008080"

    ## Blue colors ##
    PowderBlue = "#B0E0E6"
    LightBlue = "#ADD8E6"
    LightSkyBlue = "#87CEFA"
    SkyBlue = "#87CEEB"
    DeepSkyBlue = "#00BFFF"
    LightSteelBlue = "#B0C4DE"
    DodgerBlue = "#1E90FF"
    CornFlowerBlue = "#6495ED"
    SteelBlue = "#4682B4"
    RoyalBlue = "#4169E1"
    Blue = "#0000FF"
    MediumBlue = "#0000CD"
    DarkBlue = "#00008B"
    Navy = "#000080"
    MidnightBlue = "#191970"
    MediumSlateBlue = "#7B68EE"
    SlateBlue = "#6A5ACD"
    DarkSlateBlue = "#483D8B"

    ## Purple colors ##
    Lavender = "#E6E6FA"
    Thistle = "#D8BFD8"
    Plum = "#DDA0DD"
    Violet = '#EE82EE'
    Orchid = '#DA70D6'
    Fuchsia = '#FF00FF'
    Magenta = '#FF00FF'
    MediumOrchid = '#BA55D3'
    MediumPurple = '#9370DB'
    BlueViolet = '#8A2BE2'
    DarkViolet = '#9400D3'
    DarkOrchid = '#9932CC'
    DarkMagenta = '#8B008B'
    Purple = '#800080'
    Indigo = '#4B0082'

    ## Pink colors ##
    Pink = '#FFC0CB'
    LightPink = '#FFB6C1'
    HotPink = '#FF69B4'
    DeepPink = '#FF1493'
    PaleVioletred = '#DB7093'
    MediumVioletred = '#C71585'

    ## White colors ##
    White = '#FFFFFF'
    Snow = '#FFFAFA'
    HoneyDew = '#F0FFF0'
    MintCream = '#F5FFFA'
    Azure = '#F0FFFF'
    AliceBlue = '#F0F8FF'
    GhostWhite = '#F8F8FF'
    WhiteSmoke = '#F5F5F5'
    SeaShell = '#FFF5EE'
    Beige = '#F5F5DC'
    OldLace = '#FDF5E6'
    FloralWhite = '#FFFAF0'
    Ivory = '#FFFFF0'
    AntiqueWhite = '#FAEBD7'
    Linen = '#FAF0E6'
    LavenderBlush = '#FFF0F5'
    MistyRose = '#FFE4E1'

    ## Gray colors ##
    GainsBoro = '#DCDCDC'
    LightGray = '#D3D3D3'
    Silver = '#C0C0C0'
    DarkGray = '#A9A9A9'
    Gray = '#808080'
    Dimgray = '#696969'
    LightSlateGray = '#778899'
    SlateGray = '#708090'
    DarkSlateGray = '#2F4F4F'
    Black = '#000000'

    ## Brown colors ##
    CornSilk = '#FFF8DC'
    Blanchedalmond = '#FFEBCD'
    Bisque = '#FFE4C4'
    NavajoWhite = '#FFDEAD'
    Wheat = '#F5DEB3'
    BurlyWood = '#DEB887'
    Tan = '#D2B48C'
    RosyBrown = '#BC8F8F'
    SandyBrown = '#F4A460'
    Goldenrod = '#DAA520'
    Peru = '#CD853F'
    Chocolate = '#D2691E'
    SaddleBrown = '#8B4513'
    Sienna = '#A0522D'
    Brown = '#A52A2A'
    Maroon = '#800000'

from PyQt5 import QtGui,QtWidgets,QtCore
import sys

class MainApp (QtWidgets.QMainWindow):
    ## Init ##
    def __init__(self):
        super().__init__()

        ## Get all databases ##
        self.default_icon = control.read_record("app.icon.default-icon","/etc/gui")
        self.locale = control.read_record("locale","/etc/gui")
        self.direction = control.read_record("direction","/usr/share/locales/"+self.locale+"/app.locale")
        self.lc_font = control.read_record("font","/usr/share/locales/"+self.locale+"/app.locale")
        self.lc_font_size = control.read_record("font_size", "/usr/share/locales/" + self.locale + "/app.locale")
        self.bgcolor = control.read_record("app.title.bgcolor", "/etc/gui")
        self.fgcolor = control.read_record("app.title.fgcolor", "/etc/gui")

        ## Frameless the window ##
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)

        ## Customize the window  (stackoverflow.com) ##

        self.w = 1000
        self.h = 600
        self.resize(self.w,self.h)

        self.setMinimumSize(100,100)
        self.setMaximumSize(1920,1080)

        ## MainWindow = QtWidgets.QMainWindowWindow()
        self.MainWindow = QWidget()
        self.backcolor = "white"
        self.forecolor = "black"
        self.MainWindow.setStyleSheet("background-color: "+self.backcolor+';color: '+self.forecolor+";")
        self.Layout = QVBoxLayout()

        ################################
        self.MainWindow.setLayout(self.Layout)
        self.setCentralWidget(self.MainWindow)


        ## MenuBar as TitleBar ##
        self.TitleBar = self.menuBar()
        self.TitleBar.setLayoutDirection(Qt.RightToLeft)
        if not self.bgcolor==None and not self.fgcolor==None:
            self.TitleBar.setStyleSheet("background-color: "+self.bgcolor+";color: "+self.fgcolor+";")
        elif not self.bgcolor==None:
            if self.bgcolor=="#FFFFFF" or self.bgcolor=="white":
                self.TitleBar.setStyleSheet("background-color: " + self.bgcolor + ";color: black;")
            else:
                self.TitleBar.setStyleSheet("background-color: " + self.bgcolor + ";color: white;")
        elif not self.fgcolor==None:
            self.TitleBar.setStyleSheet("background-color: #00BFFF;color: "+self.fgcolor)
        else:
            self.TitleBar.setStyleSheet("background-color: #00BFFF;color: white;")

        ## Three actions ##
        self.escape = QAction()
        self.max = QAction()
        self.min = QAction()

        ## Get icons ##
        if self.direction=="ltr":
            self.escapei = control.read_record("app.icon.escape-left","/etc/gui")
        elif self.direction=="rtl":
            self.escapei = control.read_record("app.icon.escape-right", "/etc/gui")
        else:
            self.escapei = control.read_record("app.icon.escape-left", "/etc/gui")

        self.maxi = control.read_record("app.icon.max", "/etc/gui")
        self.mini = control.read_record("app.icon.min", "/etc/gui")

        ## Set icons ##
        self.escape.setIcon(QIcon(files.input(self.escapei)))
        self.max.setIcon(QIcon(files.input(self.maxi)))
        self.min.setIcon(QIcon(files.input(self.mini)))

        ## SEt triggereds ##

        self.escape.triggered.connect (exit)
        self.max.triggered.connect(self.max_act)
        self.min.triggered.connect(self.min_act)

        self.TitleBar.addAction(self.escape)
        self.TitleBar.addAction(self.max)
        self.TitleBar.addAction(self.min)

        ## TitleBar Widget ##
        self.title = QWidget()
        self.titlelayout = QHBoxLayout()
        self.ictitle = QLabel()
        if not self.default_icon==None:
            self.ictitle.setPixmap(QPixmap(files.input(self.default_icon)))
            self.ictitle.setFixedSize(25,25)
        self.lbltitle = QLabel("")
        self.titlelayout.addWidget(self.lbltitle)
        self.titlelayout.addWidget(self.ictitle)
        self.title.setLayout(self.titlelayout)
        self.TitleBar.setCornerWidget(self.title)

        ## Configure direction ##
        if self.direction == "ltr":
            self.setLayoutDirection(Qt.LeftToRight)
            self.TitleBar.setLayoutDirection(Qt.RightToLeft)
        elif self.direction == "rtl":
            self.setLayoutDirection(Qt.RightToLeft)
            self.TitleBar.setLayoutDirection(Qt.LeftToRight)

        ## Configure Font ##
        if not self.lc_font==None:
            font = QFont()
            font.setFamily(self.lc_font)
            self.setFont(font)

        if not self.lc_font_size==None:
            font = QFont()
            font.setPointSize(int(self.lc_font_size))
            self.setFont(font)

        QSizeGrip(self.MainWindow)

    maxc = False

    ## Actions ##
    def max_act(self):
        if self.maxc == False:
            self.resize(1920, 1080)
            self.maxc = True
        else:
            self.maxc = False
            self.resize(self.w, self.h)

    def min_act(self):
        self.close()

    ## Set Window Title instead of PyQt5 Window Title ##
    def SetWindowTitle (self,text):
        self.lbltitle.setText(text)

    ## Set Window Font ##
    def SetFontFamily (self,font):
        ft = QFont()
        ft.setFamily(self.font)
        self.setFont(ft)

    def SetFontSize (self,size):
        fts = QFont()
        fts.setPointSize(size)
        self.setFont(fts)

    def SetFont (self,font,size):
        ft = QFont()
        ft.setFamily(font)
        ft.setPointSize(size)
        self.setFont(ft)

    ## Disables and Enable three actions ##
    def EnableEscape (self):
        self.escape.setVisible(True)

    def EnableMinimize (self):
        self.min.setVisible(True)

    def EnableMaximize (self):
        self.max.setVisible(True)

    def DisableEscape(self):
        self.escape.setVisible(False)

    def DisableMinimize(self):
        self.min.setVisible(False)

    def DisableMaximize(self):
        self.max.setVisible(False)

    ## Resize ##
    def Resize (self,w,h):
        self.w = w
        self.h = h
        self.resize(self.w,self.h)

    ## FixedSize ##
    def SetFixedSize (self,w,h):
        self.w = w
        self.h = h
        self.setFixedSize(self.w,self.h)

    ## Maximum Size ##
    def SetMaximumSize (self,w,h):
        self.w = w
        self.h = h
        self.setMaximumSize(w,h)

    ## Minimum Size ##
    def SetMinimumSize(self, w, h):
        self.w = w
        self.h = h
        self.setMinimumSize(w, h)

    ## Set Width ##
    def SetWidth (self,w):
        self.w = w
        self.resize(self.w,self.h)

    ## Set Height ##
    def SetHeight (self,h):
        self.h = h
        self.resize(self.w,self.h)

    ## Set Fixed Width ##
    def SetFixedWidth (self,w):
        self.w = w
        self.setFixedWidth(self.w)

    ## Set Fixed Height ##
    def SetFixedHeight (self,h):
        self.h = h
        self.setFixedHeight(self.h)

    ## Set Maximums ##
    def SetMaximumWidth (self,w):
        self.setMaximumWidth(w)

    def SetMaximumHeight (self,h):
        self.setMaximumHeight(h)

    def SetMinimumWidth (self,w):
        self.setMinimumWidth(w)

    def SetMinimumHeight (self,h):
        self.setMinimumHeight(h)

    ## Set Window Title Color ##
    def SetWindowTitleColor (self,bgcolor,fgcolor):
        self.TitleBar.setStyleSheet("background-color: " + bgcolor + ";color: " + fgcolor + ";")
        
    ## Set Main Window Back Color ##
    def SetBackColor (self,color):
        self.backcolor = color
        self.MainWindow.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Set Main Window Fore Color ##
    def SetForeColor (self,color):
        self.forecolor = color
        self.MainWindow.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Set Main Window Color ##
    def SetColor (self,bgcolor,fgcolor):
        self.backcolor = bgcolor
        self.forecolor = fgcolor
        self.MainWindow.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Customize the window  (stackoverflow.com) ##
    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.__press_pos = event.pos()

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.__press_pos = None

    def mouseMoveEvent(self, event):
        if self.__press_pos:
            self.move(self.pos() + (event.pos() - self.__press_pos))

class Button (QtWidgets.QPushButton):
    def __init__ (self):
        super().__init__()

        ## Default Button Size ##
        self.w = 100
        self.h = 35
        self.setFixedSize(self.w,self.h)
        self.fontsize = 16
        self.family = "Tahoma"
        self.setFont(QFont(self.family,self.fontsize))
        
    ## Set Button Text ##
    def SetText (self,text):
        self.setText(text)
        
    ## Set Button Back Color #
    def SetBackColor (self,color):
        self.backcolor = color
        self.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Set Button Fore Color ##
    def SetForeColor (self,color):
        self.forecolor = color
        self.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Set Button Color ##
    def SetColor (self,bgcolor,fgcolor):
        self.backcolor = bgcolor
        self.forecolor = fgcolor
        self.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Set Font Family ##
    def SetFont (self,font,size):
        self.family = font
        self.fontsize = size
        ft = QFont()
        ft.setFamily(font)
        ft.setPointSize(size)
        self.setFont(ft)

    ## Set Font Family ##
    def SetFontFamily (self,font):
        self.family = font
        ft = QFont()
        ft.setFamily(self.family)
        ft.setPointSize(self.fontsize)
        self.setFont(ft)

    ## Set Font Size ##
    def SetFontSize (self,size):
        self.fontsize = size
        ft = QFont()
        ft.setPointSize(self.fontsize)
        ft.setFamily(self.family)
        self.setFont(ft)

    ## Set Size ##
    def SetSize (self,w,h):
        self.w = w
        self.h = h
        self.setFixedSize(self.w,self.h)

    ## Set Width Size ##
    def SetWidth (self,size):
        self.w = size
        self.setFixedWidth(self.w)

    ## Set Height Size ##
    def SetHeight (self,size):
        self.h = size
        self.setFixedHeight(self.h)


class TextBox (QtWidgets.QTextEdit):
    def __init__(self):
        super().__init__()
        self.fontsize = 16
        self.family = "Tahoma"
        ft = QFont()
        ft.setFamily(self.family)
        ft.setPointSize(self.fontsize)
        self.setFont(ft)

    ## Set TextBox Text ##
    def SetText(self, text):
        self.setText(text)

    ## Set TextBox Back Color #
    def SetBackColor(self, color):
        self.backcolor = color
        self.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Set TextBox Fore Color ##
    def SetForeColor(self, color):
        self.forecolor = color
        self.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Set TextBox Color ##
    def SetColor(self, bgcolor, fgcolor):
        self.backcolor = bgcolor
        self.forecolor = fgcolor
        self.setStyleSheet("background-color: " + self.backcolor + ';color: ' + self.forecolor + ";")

    ## Set Font Family ##
    def SetFont(self, font, size):
        ft = QFont()
        ft.setFamily(font)
        ft.setPointSize(size)
        self.setFont(ft)

    ## Set Font Family ##
    def SetFontFamily(self, font):
        self.family = font
        ft = QFont()
        ft.setFamily(self.family)
        ft.setPointSize(self.fontsize)
        self.setFont(ft)

    ## Set Font Size ##
    def SetFontSize(self, size):
        self.fontsize = size
        ft = QFont()
        ft.setPointSize(self.fontsize)
        ft.setFamily(self.family)
        self.setFont(ft)

    ## Set Size ##
    def SetSize(self, w, h):
        self.w = w
        self.h = h
        self.setFixedSize(self.w, self.h)

    ## Set Width Size ##
    def SetWidth(self, size):
        self.w = size
        self.setFixedWidth(self.w)

    ## Set Height Size ##
    def SetHeight(self, size):
        self.h = size
        self.setFixedHeight(self.h)