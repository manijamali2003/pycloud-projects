import sys, os, hashlib
from libnam import files, control, permissions, colors, process

def sel (database_name):
    if files.isfile(database_name):
        if permissions.check (files.output(database_name),"r",files.readall("/proc/info/su")):
            files.write("/proc/info/sel", database_name)
            files.create("/proc/selected")
        else:
            colors.show ("sel","perm","")
    else:
        colors.show("sel", "fail", database_name + ": controller not found.")

if not sys.argv == []:
    sel(sys.argv[0])
else:
    colors.show("sel", "fail", "no inputs.")