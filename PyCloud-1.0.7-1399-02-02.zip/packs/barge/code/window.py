# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'untitled.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(812, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.Title = QtWidgets.QWidget(self.centralwidget)
        self.Title.setGeometry(QtCore.QRect(0, 0, 811, 41))
        self.Title.setStyleSheet("background-color: #abcdef;")
        self.Title.setObjectName("Title")
        self.btnEscape = QtWidgets.QToolButton(self.Title)
        self.btnEscape.setGeometry(QtCore.QRect(780, 10, 25, 25))
        self.btnEscape.setStyleSheet("")
        self.btnEscape.setObjectName("btnEscape")
        self.btnMin = QtWidgets.QToolButton(self.Title)
        self.btnMin.setGeometry(QtCore.QRect(720, 10, 25, 25))
        self.btnMin.setObjectName("btnMin")
        self.btnMax = QtWidgets.QToolButton(self.Title)
        self.btnMax.setGeometry(QtCore.QRect(750, 10, 25, 25))
        self.btnMax.setObjectName("btnMax")
        self.Body = QtWidgets.QWidget(self.centralwidget)
        self.Body.setGeometry(QtCore.QRect(0, 40, 811, 531))
        self.Body.setObjectName("Body")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.btnEscape.setText(_translate("MainWindow", ">"))
        self.btnMin.setText(_translate("MainWindow", "-"))
        self.btnMax.setText(_translate("MainWindow", "[]"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
