
import hashlib, shutil, os

shutil.copyfile ("config/hostname.txt","stor/etc/hostname")

file = open ("config/password.txt","r")
passw = file.read()
file.close()

root = hashlib.sha3_256(str("root").encode()).hexdigest()
root_pass = hashlib.sha3_512(str(passw).encode()).hexdigest()

file = open ("stor/etc/users/root","w")
file.write ("username: "+root+"\n")
file.write ("code: "+root_pass+"\n")
file.close()

os.remove("config/hostname.txt")
os.remove("config/password.txt")

print ("PyCloud installed in 'stor' folder")