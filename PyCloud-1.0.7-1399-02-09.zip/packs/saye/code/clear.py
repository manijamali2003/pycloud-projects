import os
from libnam import files

osname = files.readall ("/proc/info/os")
if osname == "Windows":
    os.system("cls")
else:
    os.system("clear")