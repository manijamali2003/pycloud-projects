import sys

from libnam import permissions, files, colors

user = files.readall ("/proc/info/su")
select = files.readall("/proc/info/sel")

if not select.startswith("/proc/"):
    if permissions.check(files.output(select), "w", user):
        files.create(select)
    else:
        colors.show("clean", "perm", "")
else:
    files.create(select)