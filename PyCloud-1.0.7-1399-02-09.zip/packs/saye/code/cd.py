import sys, os, hashlib
from libnam import files, control, permissions, colors, process


def cd (path):
    if permissions.check(files.output(path),"r",files.readall("/proc/info/su")):
        if files.isdir(path):
            files.write("/proc/info/pwd", files.output_shell(path))
        else:
            colors.show("cd", "fail", path + ": directory not found.")
    else:
        colors.show ("cd","perm","")


if not sys.argv == []:
    cd(sys.argv[0])
else:
    colors.show("cd", "fail", "no inputs.")