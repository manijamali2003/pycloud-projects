import sys, os, hashlib
from libnam import files, control, permissions, colors, process

python = files.readall ("/proc/info/py")

def reboot():
    if files.isfile("/proc/selected"): files.remove("/proc/selected")
    colors.show("kernel", "reboot", "")
    if files.isdir("/desk/guest"):
        files.removedirs("/desk/guest")
    if files.isdir ("/tmp"):
        files.removedirs("/tmp")
        files.mkdir ("/tmp")
    process.endall()
    os.system(python + " vmnam.pyc")

reboot()