
# In the name of God, the Compassionte, the Merciful
# PyCloud NamNam kernel (wet) written in Python
# Virtual Memory NamNam Kernel (vmnam)
# (c) 2020 Mani Jamali All rights reserved.

import sys, socket, uuid, platform, hashlib, importlib, os, getpass

## @variables ##

hostname = ""
distro_name = ""
distro_code = ""
distro_version = ""
distro_build = ""
ip = ""
arch = ""
os_user = ""
osname = ""
python = ""
kernel_name = "NamNam"
kernel_version = "0.0.5"
user = ""
code = ""
argv = sys.argv[1:] # kernel parameters
kernel_file = "vmnam.pyc"
select = ""

## Configure kernel ###############################################################################


################## Module configure ##########################

sys.path.append("usr/lib")

from libnam import modules, files, control, colors, process, permissions

modules.get_modules() # Get all modules

################## Interface configure ##########################

## @core/interface ##

if argv == []:
    interface = files.readall ("/etc/interface").upper()

    if interface.startswith("CLI"):
        argv = ['kernel']
    elif interface.startswith("GUI"):
        argv = ['gui']
    else:
        colors.show("interface", "fail-start", "")
        colors.show("kernel", "stop", "")
        exit(0)

## @core/params-check ##

if not (argv[0] == "kernel" or
    argv[0] == "gui" or
    argv[0] == "user" or
    argv[0] == "login" or
    argv[0] == "gui-user" or
    argv[0] == "gui-login" or
    argv[0] == "exec" ):
    colors.show("params-check", "fail-start", "")
    colors.show("kernel", "stop", "")
    exit(0)
else:
    if argv[0]=='kernel' or argv[0]=='gui':
        if files.isfile ("/proc/0"):
            colors.show("params-check", "fail-start", "")
            colors.show("kernel", "stop", "")
            exit(0)

colors.argv = argv[0] ## Set color argv

## @core/exec ##

if argv[0]=='exec':
    user = files.readall("/proc/info/su")

    if argv[1].__contains__("/"):
        if files.isfile(argv[1] + ".pyc"):
            if permissions.check(files.output(argv[1]) + ".pyc", "x", user):
                sys.argv = argv[2:]
                modules.run_module(argv[1])
                exit(0)
            else:
                colors.show(argv[1], "perm", "")
                exit(0)
        else:
            colors.show(argv[1], "fail", "command not found.")
    else:
        if files.isfile("/usr/bin/"+argv[1]+".pyc"):
            if permissions.check("/usr/bin/"+files.output(argv[1]) + ".pyc", "x", user):
                sys.argv = argv[2:]
                modules.run_module(argv[1])
                exit(0)
            else:
                colors.show(argv[1], "perm", "")
                exit(0)
        else:
            colors.show(argv[1],"fail","command not found.")

###################################################################################

colors.show ("kernel","poweron","")


################## Switch configure ##########################

switch = process.processor() # Switch the process
process.check (switch) # Check the switched process

if switch == None:
    switch = 0

files.write("/proc/info/sel","/proc/"+str(switch))
select = files.readall("/proc/info/sel")

colors.show ("/proc/"+str(switch),"ok-switch","")

####################################################################################################

## @core/hostname ##

if argv[0]=="kernel" or argv[0]=="gui" or argv[0]=="login" or argv[0]=="user":
    if files.isfile("/etc/hostname"):
        files.copy("/etc/hostname", "/proc/info/host")
        hostname = files.readall("/etc/hostname")
        colors.show("hostname", "ok-start", "")
    else:
        colors.show("hostname", "fail-start", "")
        colors.show("kernel", "stop", "")
        exit(0)


## @core/distro ##

if files.isfile("/etc/distro"):
    distro_name = control.read_record("name", "/etc/distro")
    distro_code = control.read_record("code", "/etc/distro")
    distro_version = control.read_record("version", "/etc/distro")
    distro_build = control.read_record("build", "/etc/distro")
    files.write("/proc/info/cs", distro_name)
    files.write("/proc/info/cd", distro_code)
    files.write("/proc/info/ver", distro_version)
    files.write("/proc/info/bl", distro_build)
    colors.show("distro", "ok-start", "")
else:
    colors.show("distro", "fail-start", "")
    colors.show("kernel", "stop", "")
    exit(0)

## @core/kernel-info ##

colors.show("kernel-info", "ok-start", "")
files.write("/proc/info/kname", kernel_name)
files.write("/proc/info/kver", kernel_version)

## @core/system-info ##

colors.show("system-info", "ok-start", "")
ip = socket.gethostbyname(socket.gethostname())
osname = platform.system()
arch = platform.architecture()[0]
os_user = platform.node()
python = "\"" + sys.executable + "\""

if argv[0]=="kernel":
    interface = "CLI"
else:
    interface = "GUI"

files.write("/proc/info/ip", ip)
files.write("/proc/info/os", osname)
files.write("/proc/info/arch", arch)
files.write("/proc/info/os_su", os_user)
files.write("/proc/info/py", python)
files.write("/proc/info/inter",interface)

## @core/dirs ##

if argv[0]=="kernel" or argv[0]=="gui":
    colors.show("dirs", "ok-start", "")
    if not files.isdir("/app"): files.mkdir("/app")
    if not files.isdir("/app/cache"): files.mkdir("/app/cache")
    if not files.isdir("/app/cache/gets"): files.mkdir("/app/cache/gets")
    if not files.isdir("/app/cache/archives"): files.mkdir("/app/cache/archives")
    if not files.isdir("/app/cache/archives/build"): files.mkdir("/app/cache/archives/build")
    if not files.isdir("/app/cache/archives/control"): files.mkdir("/app/cache/archives/control")
    if not files.isdir("/app/cache/archives/code"): files.mkdir("/app/cache/archives/code")
    if not files.isdir("/app/cache/archives/data"): files.mkdir("/app/cache/archives/data")
    if not files.isdir("/app/packages"): files.mkdir("/app/packages")
    if not files.isdir("/desk"): files.mkdir("/desk")
    if not files.isdir("/desk/guest"): files.mkdir("/desk/guest")
    if not files.isdir("/etc"): files.mkdir("/etc")
    if not files.isdir("/etc/users"): files.mkdir("/etc/users")
    if not files.isdir("/proc"): files.mkdir("/proc")
    if not files.isdir("/proc/id"): files.mkdir("/proc/id")
    if not files.isdir("/proc/info"): files.mkdir("/proc/info")
    if not files.isdir("/root"): files.mkdir("/root")
    if not files.isdir("/opt"): files.mkdir("/opt")
    if not files.isdir("/stor"): files.mkdir("/stor")
    if not files.isdir("/tmp"): files.mkdir("/tmp")
    if not files.isdir("/usr"): files.mkdir("/usr")
    if not files.isdir("/usr/bin"): files.mkdir("/usr/bin")
    if not files.isdir("/usr/games"): files.mkdir("/usr/games")
    if not files.isdir("/usr/include"): files.mkdir("/usr/include")
    if not files.isdir("/usr/lib"): files.mkdir("/usr/lib")
    if not files.isdir("/usr/share"): files.mkdir("/usr/share")
    if not files.isdir("/usr/share/applications"): files.mkdir("/usr/share/applications")
    if not files.isdir("/usr/share/docs"): files.mkdir("/usr/share/docs")
    if not files.isdir("/usr/share/fonts"): files.mkdir("/usr/share/fonts")
    if not files.isdir("/usr/share/icons"): files.mkdir("/usr/share/icons")
    if not files.isdir("/usr/share/etcetra"): files.mkdir("/usr/share/etcetra")
    if not files.isdir("/usr/share/images"): files.mkdir("/usr/share/images")
    if not files.isdir("/usr/share/backgrounds"): files.mkdir("/usr/share/backgrounds")
    if not files.isdir("/usr/share/locales"): files.mkdir("/usr/share/locales")
    if not files.isdir("/usr/share/themes"): files.mkdir("/usr/share/themes")
    if not files.isdir("/usr/src"): files.mkdir("/usr/src")

## @core/welcome ##

if argv[0]=="kernel":
    colors.show("welcome", "ok-start", "")
    print ()
    print ("Welcome to "+distro_name+" "+distro_version+" ("+distro_code+") clouding system.")
    print()

## @core/issue ##

if (argv[0]=="kernel") and files.isfile ("/etc/issue"):
    colors.show("issue","ok-start","")
    print ()
    print (files.readall("/etc/issue"))
    print ()

## @core/gui ##

if argv[0]=="gui":
    if files.isfile ("/usr/bin/backend.pyc"):
        colors.show ("gui","ok-start","")
        modules.run_module ("backend")
    else:
        colors.show ("gui","fail-start","")
        colors.show ("kernel","stop","")
    exit(0)

## @core/gui-login ##

if argv[0]=="gui-login":
    if files.isfile ("/usr/bin/login.pyc"):
        colors.show ("gui","ok-start","")
        modules.run_module ("login")
    else:
        colors.show ("gui-login","fail-start","")
        colors.show ("kernel","stop","")
    exit(0)

## @lib/shell ##

def shell():
    print()

    if user=="root":
        files.write("/proc/info/pwd","/root")
    else:
        files.write("/proc/info/pwd","/desk/"+user)

    select = files.readall ("/proc/info/sel")  # Change selected database

    while True:
        if not files.isfile ("/proc/selected"):
            files.write("/proc/info/sel", "/proc/" + str(switch))  ## Write this controller
        ## Check the switched process ##
        process.check(switch)  # Check the switched process

        files.write("/proc/info/sp", str(switch))  # Write switched process

        if files.isfile ("/tmp/su.tmp"): files.remove ("/tmp/su.tmp")

        ## User configure check ##
        files.write("/proc/info/su",user) # Write user name in info processor
        if not user=="guest":
            hashname = hashlib.sha3_256(str(user).encode()).hexdigest()
            username = control.read_record("username","/etc/users/"+user)
            hashcode = hashlib.sha3_512(str(code).encode()).hexdigest()
            password = control.read_record("code","/etc/users/"+user)

            if not (hostname==username) and not (password==hashcode):
                colors.show("shell","fail-start","")
                colors.show("kernel","stop","")
                exit(0)
        ## PWD path setting up at all ##
        if not user == "root":
            if not files.isdir("/desk/" + user): files.mkdir("/desk/" + user)  # Create home folder

        ## Prompt data base ##

        show_username = control.read_record("show_username", "/etc/prompt")
        show_hostname = control.read_record("show_hostname", "/etc/prompt")
        show_path = control.read_record("show_path", "/etc/prompt")
        root_symbol = control.read_record("root","/etc/prompt")
        user_symbol = control.read_record("user", "/etc/prompt")

        ## Setting up prompt data base 2 ##

        color_uh = ""
        color_path = ""
        prompt_symbol = ""

        if user=="root":
            prompt_symbol = root_symbol
            color_uh = colors.get_colors()
            color_path = colors.get_colors()
        else:
            prompt_symbol = user_symbol
            color_uh = colors.get_ok()
            color_path = colors.get_path()

        ## Setting up space of prompt ##

        if show_username == "Yes":
            space_username = user
        else:
            space_username = ""

        if show_hostname == "Yes":
            space_hostname = hostname
        else:
            space_hostname = ""

        if show_path == "Yes":
            space_path = files.readall("/proc/info/pwd")
        else:
            space_path = ""

        if show_hostname == "Yes" and show_username == "Yes":
            space1 = "@"
        else:
            space1 = ""

        if (show_hostname == "Yes" or show_username == "Yes") and show_path == "Yes":
            space2 = ":"
        else:
            space2 = ""

        ## Shell prompt ##

        cmd = input(color_uh + space_username + space1 + space_hostname + colors.get_colors() + space2 + color_path + space_path + colors.get_colors() + prompt_symbol + " ")

        cmdln = cmd.split(" ")


        strcmdln = ""

        for i in cmdln:
            if str(i).startswith("$"):
                select = files.readall("/proc/info/sel")
                var = control.read_record(str(i).replace("$",""),select)
                if var==None:
                    strcmdln = strcmdln + " " + i
                else:
                    strcmdln = strcmdln + " " + var
            else:
                strcmdln = strcmdln + " " + i

        ## Command line ##
        cmdln = strcmdln.split(" ")
        cmdln.remove ('')

        ## All commands run in here ##

        ## New command ##
        if cmdln[0]=="new":
            files.create ("/tmp/su.tmp")
            if cmdln[0]=="new":
                control.write_record ("username",user,"/tmp/su.tmp")
                control.write_record ("code",code,"/tmp/su.tmp")


        ## Other commands ##
        if (cmdln == [] or
                cmdln[0] == "" or
                cmdln[0] == " " or
                cmd.startswith("#") or
                cmd.startswith("//") or
                (cmd.startswith("/*") and cmd.endswith("*/")) or
                (cmd.startswith("\'\'\'") and cmd.endswith("\'\'\'")) or
                cmd.startswith(";")
        ):
            continue
        else:
            cmd = ""
            for i in cmdln:
                cmd = cmd + " " + i
            os.system (python+" "+kernel_file+" exec "+cmd)

## @core/user ##

if argv[0]=="user":
    input_username = argv[1]
    if input_username=="guest":
        enable_cli = control.read_record("enable_cli", "/etc/guest")
        if enable_cli == "Yes":
            ## Set variables ##
            user = "guest"
            code = "*"
            ## Create info ##
            files.write("/proc/info/su", input_username)
            shell()
            exit(0)
        else:
            colors.show(input_username, "fail", "user not found.")
    else:
        input_password = argv[2]
        hashname = hashlib.sha3_256(str(input_username).encode()).hexdigest()
        hashcode = hashlib.sha3_512(str(input_password).encode()).hexdigest()

        if files.isfile ("/etc/users/"+input_username):
            username = control.read_record("username","/etc/users/"+input_username)
            password = control.read_record("code","/etc/users/"+input_username)
            if username==hashname and password==hashcode:
                ## Set variables ##
                user = input_username
                code = input_password
                ## Create info ##
                files.write("/proc/info/su", input_username)
                permissions.user = user
                permissions.code = code
                shell()
                exit(0)
            else:
                colors.show("user", "fail-start", "")
                colors.show("kernel", "stop", "")
                exit(0)
        else:
            colors.show ("user","fail-start","")
            colors.show ("kernel","stop","")
            exit(0)

## @core/login ##

if argv[0]=="kernel" or argv[0]=="login":
    colors.show ("login","ok-start","")
    while True:
        print()

        process.check(switch)  # Check the switched process

        input_username = input("Enter an username: ")
        if input_username == "" or input_username == " ":
            continue
        elif input_username == "guest":
            enable_cli = control.read_record("enable_cli", "/etc/guest")
            if enable_cli == "Yes":
                ## Set variables ##
                user = "guest"
                code = "*"
                ## Create info ##
                files.write("/proc/info/su", input_username)
                permissions.user = user
                permissions.code = code
                shell()
                exit(0)
            else:
                colors.show(input_username, "fail", "user not found.")
        elif files.isfile("/etc/users/" + input_username):
            hashname = hashlib.sha3_256(
                str(input_username).encode()).hexdigest()  # Hashname creator from input_username
            username = control.read_record("username", "/etc/users/" + input_username)
            if not hostname == input_username:
                input_password = getpass.getpass("Enter " + input_username + "'s password: ")
                hashcode = hashlib.sha3_512(
                    str(input_password).encode()).hexdigest()  # Hashcode creator from input_password
                password = control.read_record("code", "/etc/users/" + input_username)
                if hashcode == password:
                    ## Set variables ##
                    user = input_username
                    code = input_password
                    ## Create info ##
                    files.write("/proc/info/su", input_username)
                    permissions.user = user
                    permissions.code = code
                    shell()
                    exit(0)
                else:
                    colors.show(input_username, "fail", "wrong password.")
            else:
                colors.show(input_username, "fail", "user not found.")
        else:
            colors.show(input_username, "fail", "user not found.")
